using DataAccess.DAOs;
using DataAccess.Models;
using Microsoft.EntityFrameworkCore;

namespace Q1
{
    public partial class Form1 : Form
    {
        private string searchValue;
        private Sex sex;
        private string position;
        public Form1()
        {
            InitializeComponent();
            searchValue = string.Empty;
            sex = Sex.None;
            position = "All Position";
            radioMaleOrFemale.Checked = true;
            EmployeeDAO dao = new EmployeeDAO();
            cboPosition.DataSource = dao.GetPositions();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadEmployee();

        }

        public void LoadEmployee()
        {
            EmployeeDAO dao = new EmployeeDAO();
            dgvEmployeeList.DataSource = dao.GetFilter(searchValue, sex, position);
        }


        private void txtName_TextChanged(object sender, EventArgs e)
        {
            searchValue = txtName.Text.Trim();

            // Reload employee list based on updated filters
            LoadEmployee();
        }



        private void radioMale_CheckedChanged(object sender, EventArgs e)
        {
            if (radioMale.Checked)
            {
                // Update sex filter to Male
                sex = Sex.Male;

                // Reload employee list based on updated filters
                LoadEmployee();
            }
        }

        private void radioMaleOrFemale_CheckedChanged(object sender, EventArgs e)
        {
            if (radioMaleOrFemale.Checked)
            {
                sex = Sex.None;

                LoadEmployee();
            }
        }

        private void radioFemale_CheckedChanged(object sender, EventArgs e)
        {
            if (radioFemale.Checked)
            {
                // Update sex filter to Female
                sex = Sex.Female;

                // Reload employee list based on updated filters
                LoadEmployee();
            }
        }

        private void cboPosition_SelectedIndexChanged(object sender, EventArgs e)
        {
            position = cboPosition.SelectedItem.ToString();

            // Reload employee list based on updated filters
            LoadEmployee();
        }
    }
}
