﻿namespace Q1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvEmployeeList = new DataGridView();
            groupBox1 = new GroupBox();
            cboPosition = new ComboBox();
            radioFemale = new RadioButton();
            radioMale = new RadioButton();
            radioMaleOrFemale = new RadioButton();
            txtName = new TextBox();
            label2 = new Label();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvEmployeeList).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // dgvEmployeeList
            // 
            dgvEmployeeList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEmployeeList.Location = new Point(322, 46);
            dgvEmployeeList.Name = "dgvEmployeeList";
            dgvEmployeeList.RowTemplate.Height = 25;
            dgvEmployeeList.Size = new Size(578, 333);
            dgvEmployeeList.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(cboPosition);
            groupBox1.Controls.Add(radioFemale);
            groupBox1.Controls.Add(radioMale);
            groupBox1.Controls.Add(radioMaleOrFemale);
            groupBox1.Controls.Add(txtName);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(36, 46);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(251, 333);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Filter";
            // 
            // cboPosition
            // 
            cboPosition.FormattingEnabled = true;
            cboPosition.Location = new Point(65, 118);
            cboPosition.Name = "cboPosition";
            cboPosition.Size = new Size(121, 23);
            cboPosition.TabIndex = 6;
            cboPosition.SelectedIndexChanged += cboPosition_SelectedIndexChanged;
            // 
            // radioFemale
            // 
            radioFemale.AutoSize = true;
            radioFemale.Location = new Point(170, 76);
            radioFemale.Name = "radioFemale";
            radioFemale.Size = new Size(63, 19);
            radioFemale.TabIndex = 5;
            radioFemale.TabStop = true;
            radioFemale.Text = "Female";
            radioFemale.UseVisualStyleBackColor = true;
            radioFemale.CheckedChanged += radioFemale_CheckedChanged;
            // 
            // radioMale
            // 
            radioMale.AutoSize = true;
            radioMale.Location = new Point(113, 76);
            radioMale.Name = "radioMale";
            radioMale.Size = new Size(51, 19);
            radioMale.TabIndex = 4;
            radioMale.TabStop = true;
            radioMale.Text = "Male";
            radioMale.UseVisualStyleBackColor = true;
            radioMale.CheckedChanged += radioMale_CheckedChanged;
            // 
            // radioMaleOrFemale
            // 
            radioMaleOrFemale.AutoSize = true;
            radioMaleOrFemale.Location = new Point(13, 76);
            radioMaleOrFemale.Name = "radioMaleOrFemale";
            radioMaleOrFemale.Size = new Size(94, 19);
            radioMaleOrFemale.TabIndex = 3;
            radioMaleOrFemale.TabStop = true;
            radioMaleOrFemale.Text = "Male/Female";
            radioMaleOrFemale.UseVisualStyleBackColor = true;
            radioMaleOrFemale.CheckedChanged += radioMaleOrFemale_CheckedChanged;
            // 
            // txtName
            // 
            txtName.Location = new Point(64, 22);
            txtName.Name = "txtName";
            txtName.Size = new Size(158, 23);
            txtName.TabIndex = 2;
            txtName.TextChanged += txtName_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 123);
            label2.Name = "label2";
            label2.Size = new Size(50, 15);
            label2.TabIndex = 1;
            label2.Text = "Position";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 29);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 0;
            label1.Text = "Name";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(912, 450);
            Controls.Add(groupBox1);
            Controls.Add(dgvEmployeeList);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvEmployeeList).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvEmployeeList;
        private GroupBox groupBox1;
        private ComboBox cboPosition;
        private RadioButton radioFemale;
        private RadioButton radioMale;
        private RadioButton radioMaleOrFemale;
        private TextBox txtName;
        private Label label2;
        private Label label1;
    }
}
