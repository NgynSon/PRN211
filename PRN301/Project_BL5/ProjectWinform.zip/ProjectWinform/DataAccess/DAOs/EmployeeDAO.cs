﻿using DataAccess.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.DAOs
{
    public class EmployeeDAO
    {
        private HotelManagementContext context;

        public EmployeeDAO()
        {
            context = new HotelManagementContext();
        }

        public void AddNewEmployee(Employee newEmployee)
        {
            try
            {
                context.Employees.Add(newEmployee);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while adding a new Employee: {ex.Message}");
                throw;
            }
        }

        public List<Employee> GetAllEmployees()
        {
            return context.Employees.ToList();
        }

        public void DeleteEmployee(int employeeId)
        {
            try
            {
                Employee employeeToDelete = context.Employees.Find(employeeId);

                if (employeeToDelete != null)
                {
                    context.Employees.Remove(employeeToDelete);
                    context.SaveChanges(); 
                }
                else
                {
                    Console.WriteLine($"Employee with ID {employeeId} not found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while deleting Employee: {ex.Message}");
                throw;
            }
        }
        public Employee GetEmployeeById(int employeeId)
        {
            try
            {
                Employee employee = context.Employees.FirstOrDefault(e => e.EmployeeId == employeeId);
                return employee; 
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while getting Employee by ID: {ex.Message}");
                throw;
            }
        }


        public void UpdateEmployee(Employee updatedEmployee)
        {
            try
            {
                Employee existingEmployee = context.Employees.Find(updatedEmployee.EmployeeId);

                if (existingEmployee != null)
                {
                    existingEmployee.FirstName = updatedEmployee.FirstName;
                    existingEmployee.LastName = updatedEmployee.LastName;
                    existingEmployee.Address = updatedEmployee.Address;
                    existingEmployee.Email = updatedEmployee.Email;
                    existingEmployee.Phone = updatedEmployee.Phone;
                    existingEmployee.Salary = updatedEmployee.Salary;
                    existingEmployee.Position = updatedEmployee.Position;

                    context.SaveChanges();
                }
                else
                {
                    throw new Exception($"Employee with ID {updatedEmployee.EmployeeId} not found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while updating Employee: {ex.Message}");
                throw;
            }
        }

        public List<string> GetAvailablePositions(string selectedRoomType)
        {
            List<Employee> filterePosition = context.Employees
                .Where(r => r.Position == selectedRoomType)
                .ToList();
            List<string> positions = filterePosition.Select(r => r.Position).ToList();

            return positions;
        }

        public List<Employee> SearchEmployeeByNameOrAddress(string searchText)
        {
            EmployeeDAO employeeDAO = new EmployeeDAO();
            List<Employee> allEmployees = employeeDAO.GetAllEmployees();

            // Filter employees whose first name or last name contains the search text
            List<Employee> filteredEmployees = allEmployees.Where(emp =>
                emp.FirstName != null && emp.FirstName.Contains(searchText, StringComparison.OrdinalIgnoreCase) ||
                emp.LastName != null && emp.LastName.Contains(searchText, StringComparison.OrdinalIgnoreCase)
            ).ToList();

           

            return filteredEmployees;
        }
    }
}
