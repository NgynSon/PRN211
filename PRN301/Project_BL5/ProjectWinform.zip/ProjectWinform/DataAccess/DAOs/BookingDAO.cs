﻿using DataAccess.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.DAOs
{
    public class BookingDAO
    {
        private HotelManagementContext context;

        public BookingDAO()
        {
            context = new HotelManagementContext();
        }

        public bool AddBooking(Booking newBooking)
        {
            try
            {
                context.Bookings.Add(newBooking);
                context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while adding a new booking: {ex.ToString()}");
                return false;
            }
        }



    }
}
