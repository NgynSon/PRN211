﻿using DataAccess.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.DAOs
{
    public class RoomDAO
    {
        private HotelManagementContext context;

        public RoomDAO()
        {
            context = new HotelManagementContext();
        }

        public List<Room> GetAllRooms()
        {
            if (context == null)
            {
                throw new InvalidOperationException("Manage_hotelContext is not initialized.");
            }

            return context.Rooms.ToList();
        }

        public bool IsRoomNumberExists(string roomNumber)
        {
            var existingRoom = context.Rooms.FirstOrDefault(r => r.RoomName == roomNumber);
            return existingRoom != null;
        }

        public void AddNewRoom(Room newRoom)
        {
            try
            {
                context.Rooms.Add(newRoom);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while adding a new room: {ex.Message}");
                throw;
            }
        }

        public List<string> GetAvailableRoomNos( string selectedRoomType)
        {
            List<Room> filteredRooms = context.Rooms
                .Where(r => r.RoomType == selectedRoomType && r.Status == "Empty")
                .ToList();
            List<string> roomNos = filteredRooms.Select(r => r.RoomName).ToList();

            return roomNos;
        }

        public Room GetRoomByRoomNo(string roomNo)
        {
            Room room = context.Rooms.FirstOrDefault(r => r.RoomName == roomNo && r.Status == "Empty");

            return room;
        }



        public void UpdateRoomBookedStatus(string roomNo, string bookedStatus)
        {
            // Tìm phòng dựa trên RoomNo
            Room roomToUpdate = context.Rooms.FirstOrDefault(r => r.RoomName == roomNo);

            if (roomToUpdate != null)
            {
                // Cập nhật trạng thái booked của phòng
                roomToUpdate.Status = bookedStatus;
                context.SaveChanges();
            }
            else
            {
                // Xử lý khi không tìm thấy phòng
                throw new Exception($"Room with RoomNo '{roomNo}' not found.");
            }
        }

    }
}
