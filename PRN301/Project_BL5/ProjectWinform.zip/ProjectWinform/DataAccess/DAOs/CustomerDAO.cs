﻿using DataAccess.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.DAOs
{
    public class CustomerDAO
    {
        private HotelManagementContext context;

        public CustomerDAO()
        {
            context = new HotelManagementContext();
        }
        public bool AddNewCustomer(Customer newCustomer)
        {
            try
            {
                context.Customers.Add(newCustomer);
                context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while adding a new customer: {ex.Message}");
                return false;
            }
        }

        public List<Customer> GetAllCustomersWithBookings()
        {
            try
            {
                return context.Customers
                    .Include(c => c.Bookings)
                        .ThenInclude(b => b.Room)
                    .ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while retrieving customers with bookings: {ex.Message}");
                return new List<Customer>();
            }
        }

        public List<Customer> GetCustomersWithBookingsByRoomStatus(string roomStatus)
        {
            try
            {
                return context.Customers
                    .Include(c => c.Bookings)
                        .ThenInclude(b => b.Room)
                    .Where(c => c.Bookings.Any(b => b.Room != null && b.Room.Status == roomStatus))
                    .ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while retrieving customers with bookings by room status: {ex.Message}");
                return new List<Customer>();
            }
        }


        public List<Customer> SearchCustomersByName(string searchName)
        {
            // Filter customers by name using LINQ
            List<Customer> filteredCustomers = context.Customers
                .Where(c => (c.FirstName + c.LastName).Contains(searchName))
                .ToList();

            return filteredCustomers;
        }

        public List<Customer> SearchCusByName(string searchName)
        {
            // Filter employees whose first name or last name contains the search text
            List<Customer> filteredCustomers = context.Customers
       .Where(c => c.FirstName.Contains(searchName) || c.LastName.Contains(searchName))
       .ToList();

            return filteredCustomers;
        }

        public void RemoveBookingByRoom(string roomName, string customerName)
        {
            Customer customer = context.Customers.FirstOrDefault(c => c.FirstName + " " + c.LastName == customerName);
            if (customer != null)
            {
                Booking bookingToRemove = customer.Bookings.FirstOrDefault(b => b.Room?.RoomName == roomName);
                if (bookingToRemove != null)
                {
                    context.Bookings.Remove(bookingToRemove);
                    context.SaveChanges();
                }
                else
                {
                    throw new Exception($"Booking for room '{roomName}' not found for customer '{customerName}'.");
                }
            }
            else
            {
                throw new Exception($"Customer '{customerName}' not found.");
            }
        }

    }
}
