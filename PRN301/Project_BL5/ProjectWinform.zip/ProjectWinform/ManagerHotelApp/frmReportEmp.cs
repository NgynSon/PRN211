﻿using DataAccess.DAOs;
using DataAccess.Data;
using Excel = Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManagerHotelApp
{
    public partial class frmReportEmp : Form
    {
        public frmReportEmp()
        {
            InitializeComponent();
        }
        private void frmReportEmp_Load(object sender, EventArgs e)
        {
            loadEmployee();
        }
        private void loadEmployee()
        {
            EmployeeDAO employeeDAO = new EmployeeDAO();
            List<Employee> employee = employeeDAO.GetAllEmployees();

            dgvListDetails.DataSource = employee;
        }

        private void cmbPos_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedPosition = cmbPos.Text;
            EmployeeDAO empDAO = new EmployeeDAO();
            List<string> positions = empDAO.GetAvailablePositions(selectedPosition);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            EmployeeDAO employeeDAO=new EmployeeDAO();
            string searchText = txtSearch.Text.Trim();
            List<Employee> filteredEmployees = employeeDAO.SearchEmployeeByNameOrAddress(searchText);
            dgvListDetails.DataSource = filteredEmployees;

        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            ExportToExcel(dgvListDetails);
        }
       
        private void ExportToExcel(DataGridView dataGridView)
        {
            // Tạo một đối tượng Excel mới
            Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();
            excelApp.Visible = true;

            // Tạo một workbook mới
            Microsoft.Office.Interop.Excel.Workbook workbook = excelApp.Workbooks.Add(Type.Missing);
            // Lấy sheet đầu tiên (worksheet)
            Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.ActiveSheet;

            // Đặt tên cột trong Excel từ DataGridView
            for (int i = 1; i <= dataGridView.Columns.Count; i++)
            {
                worksheet.Cells[1, i] = dataGridView.Columns[i - 1].HeaderText;
            }

            // Đổ dữ liệu từ DataGridView vào Excel
            for (int i = 0; i < dataGridView.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView.Columns.Count; j++)
                {
                    string value = dataGridView.Rows[i].Cells[j].Value.ToString();                  

                    // Kiểm tra nếu là cột "salary" thì loại bỏ phần thập phân ".00"
                    if (dataGridView.Columns[j].HeaderText.ToLower() == "salary")
                    {
                        decimal salary = decimal.Parse(value);
                        value = salary.ToString("0");
                    }

                    worksheet.Cells[i + 2, j + 1] = value;
                }
            }

            // Lưu file Excel
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
            saveDialog.FilterIndex = 2;
            saveDialog.RestoreDirectory = true;

            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                workbook.SaveAs(saveDialog.FileName);
            }

            // Đóng workbook và Excel application
            workbook.Close();
            excelApp.Quit();

            ReleaseObject(worksheet);
            ReleaseObject(workbook);
            ReleaseObject(excelApp);
        }
        private void ReleaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
    }
}
