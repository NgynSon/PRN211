﻿namespace ManagerHotelApp
{
    partial class frmDashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashBoard));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            btnExit = new Guna.UI2.WinForms.Guna2Button();
            btnMinisize = new Guna.UI2.WinForms.Guna2Button();
            panel1 = new Panel();
            btnMangeEmployee = new Guna.UI2.WinForms.Guna2Button();
            btnCustomerDetails = new Guna.UI2.WinForms.Guna2Button();
            btnCheckout = new Guna.UI2.WinForms.Guna2Button();
            btnCusRegister = new Guna.UI2.WinForms.Guna2Button();
            btnAddRoom = new Guna.UI2.WinForms.Guna2Button();
            panel2 = new Panel();
            uC_Employees1 = new AllUser.UC_Employees();
            uC_CustomerDetail1 = new AllUser.UC_CustomerDetail();
            uC_Checkout1 = new AllUser.UC_Checkout();
            uC_Register1 = new AllUser.UC_Register();
            uC_AddRoom1 = new AllUser.UC_AddRoom();
            panelMoving = new Guna.UI2.WinForms.Guna2Panel();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse4 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse5 = new Guna.UI2.WinForms.Guna2Elipse(components);
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // btnExit
            // 
            btnExit.CustomizableEdges = customizableEdges1;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.FromArgb(132, 122, 225);
            btnExit.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnExit.ForeColor = Color.White;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.Location = new Point(0, 1);
            btnExit.Name = "btnExit";
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnExit.Size = new Size(25, 26);
            btnExit.TabIndex = 0;
            btnExit.Click += btnExit_Click;
            // 
            // btnMinisize
            // 
            btnMinisize.CustomizableEdges = customizableEdges3;
            btnMinisize.DisabledState.BorderColor = Color.DarkGray;
            btnMinisize.DisabledState.CustomBorderColor = Color.DarkGray;
            btnMinisize.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnMinisize.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnMinisize.FillColor = Color.FromArgb(132, 122, 225);
            btnMinisize.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnMinisize.ForeColor = Color.White;
            btnMinisize.Image = (Image)resources.GetObject("btnMinisize.Image");
            btnMinisize.Location = new Point(0, 44);
            btnMinisize.Name = "btnMinisize";
            btnMinisize.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnMinisize.Size = new Size(35, 36);
            btnMinisize.TabIndex = 1;
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(btnMangeEmployee);
            panel1.Controls.Add(btnCustomerDetails);
            panel1.Controls.Add(btnCheckout);
            panel1.Controls.Add(btnCusRegister);
            panel1.Controls.Add(btnAddRoom);
            panel1.Location = new Point(41, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(912, 73);
            panel1.TabIndex = 2;
            // 
            // btnMangeEmployee
            // 
            btnMangeEmployee.BorderRadius = 18;
            btnMangeEmployee.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnMangeEmployee.CustomizableEdges = customizableEdges5;
            btnMangeEmployee.DisabledState.BorderColor = Color.DarkGray;
            btnMangeEmployee.DisabledState.CustomBorderColor = Color.DarkGray;
            btnMangeEmployee.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnMangeEmployee.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnMangeEmployee.FillColor = Color.SlateBlue;
            btnMangeEmployee.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnMangeEmployee.ForeColor = Color.White;
            btnMangeEmployee.Location = new Point(750, 3);
            btnMangeEmployee.Name = "btnMangeEmployee";
            btnMangeEmployee.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnMangeEmployee.Size = new Size(155, 63);
            btnMangeEmployee.TabIndex = 4;
            btnMangeEmployee.Text = "Manage Employee";
            btnMangeEmployee.Click += btnMangeEmployee_Click;
            // 
            // btnCustomerDetails
            // 
            btnCustomerDetails.BorderRadius = 18;
            btnCustomerDetails.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnCustomerDetails.CustomizableEdges = customizableEdges7;
            btnCustomerDetails.DisabledState.BorderColor = Color.DarkGray;
            btnCustomerDetails.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCustomerDetails.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCustomerDetails.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCustomerDetails.FillColor = Color.SlateBlue;
            btnCustomerDetails.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnCustomerDetails.ForeColor = Color.White;
            btnCustomerDetails.Location = new Point(564, 3);
            btnCustomerDetails.Name = "btnCustomerDetails";
            btnCustomerDetails.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnCustomerDetails.Size = new Size(155, 63);
            btnCustomerDetails.TabIndex = 3;
            btnCustomerDetails.Text = "Customer Details";
            btnCustomerDetails.Click += btnCustomerDetails_Click;
            // 
            // btnCheckout
            // 
            btnCheckout.BorderRadius = 18;
            btnCheckout.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnCheckout.CustomizableEdges = customizableEdges9;
            btnCheckout.DisabledState.BorderColor = Color.DarkGray;
            btnCheckout.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCheckout.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCheckout.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCheckout.FillColor = Color.SlateBlue;
            btnCheckout.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnCheckout.ForeColor = Color.White;
            btnCheckout.Location = new Point(376, 3);
            btnCheckout.Name = "btnCheckout";
            btnCheckout.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnCheckout.Size = new Size(155, 63);
            btnCheckout.TabIndex = 2;
            btnCheckout.Text = "Check Out";
            btnCheckout.Click += btnCheckout_Click;
            // 
            // btnCusRegister
            // 
            btnCusRegister.BorderRadius = 18;
            btnCusRegister.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnCusRegister.CustomizableEdges = customizableEdges11;
            btnCusRegister.DisabledState.BorderColor = Color.DarkGray;
            btnCusRegister.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCusRegister.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCusRegister.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCusRegister.FillColor = Color.SlateBlue;
            btnCusRegister.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnCusRegister.ForeColor = Color.White;
            btnCusRegister.Location = new Point(184, 3);
            btnCusRegister.Name = "btnCusRegister";
            btnCusRegister.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnCusRegister.Size = new Size(155, 63);
            btnCusRegister.TabIndex = 1;
            btnCusRegister.Text = "Customer Register";
            btnCusRegister.Click += btnCusRegister_Click;
            // 
            // btnAddRoom
            // 
            btnAddRoom.BorderRadius = 18;
            btnAddRoom.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnAddRoom.CustomizableEdges = customizableEdges13;
            btnAddRoom.DisabledState.BorderColor = Color.DarkGray;
            btnAddRoom.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAddRoom.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAddRoom.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAddRoom.FillColor = Color.SlateBlue;
            btnAddRoom.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnAddRoom.ForeColor = Color.White;
            btnAddRoom.Location = new Point(3, 3);
            btnAddRoom.Name = "btnAddRoom";
            btnAddRoom.ShadowDecoration.CustomizableEdges = customizableEdges14;
            btnAddRoom.Size = new Size(146, 63);
            btnAddRoom.TabIndex = 0;
            btnAddRoom.Text = "Add Room";
            btnAddRoom.Click += btnAddRoom_Click;
            // 
            // panel2
            // 
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(uC_Employees1);
            panel2.Controls.Add(uC_CustomerDetail1);
            panel2.Controls.Add(uC_Checkout1);
            panel2.Controls.Add(uC_Register1);
            panel2.Controls.Add(uC_AddRoom1);
            panel2.Location = new Point(12, 117);
            panel2.Name = "panel2";
            panel2.Size = new Size(956, 499);
            panel2.TabIndex = 3;
            // 
            // uC_Employees1
            // 
            uC_Employees1.BackColor = Color.White;
            uC_Employees1.Location = new Point(-1, -1);
            uC_Employees1.Name = "uC_Employees1";
            uC_Employees1.Size = new Size(956, 499);
            uC_Employees1.TabIndex = 4;
            // 
            // uC_CustomerDetail1
            // 
            uC_CustomerDetail1.BackColor = Color.White;
            uC_CustomerDetail1.Location = new Point(-1, -1);
            uC_CustomerDetail1.Name = "uC_CustomerDetail1";
            uC_CustomerDetail1.Size = new Size(956, 499);
            uC_CustomerDetail1.TabIndex = 3;
            // 
            // uC_Checkout1
            // 
            uC_Checkout1.BackColor = Color.White;
            uC_Checkout1.Location = new Point(-1, -1);
            uC_Checkout1.Name = "uC_Checkout1";
            uC_Checkout1.Size = new Size(956, 499);
            uC_Checkout1.TabIndex = 2;
            // 
            // uC_Register1
            // 
            uC_Register1.BackColor = Color.White;
            uC_Register1.Location = new Point(-1, -1);
            uC_Register1.Name = "uC_Register1";
            uC_Register1.Size = new Size(956, 499);
            uC_Register1.TabIndex = 1;
            // 
            // uC_AddRoom1
            // 
            uC_AddRoom1.BackColor = Color.White;
            uC_AddRoom1.Location = new Point(-1, -1);
            uC_AddRoom1.Name = "uC_AddRoom1";
            uC_AddRoom1.Size = new Size(956, 499);
            uC_AddRoom1.TabIndex = 0;
            // 
            // panelMoving
            // 
            panelMoving.BackColor = Color.Cyan;
            panelMoving.CustomizableEdges = customizableEdges15;
            panelMoving.Location = new Point(46, 91);
            panelMoving.Name = "panelMoving";
            panelMoving.ShadowDecoration.CustomizableEdges = customizableEdges16;
            panelMoving.Size = new Size(134, 5);
            panelMoving.TabIndex = 4;
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.TargetControl = this;
            // 
            // guna2Elipse2
            // 
            guna2Elipse2.TargetControl = this;
            // 
            // guna2Elipse3
            // 
            guna2Elipse3.TargetControl = this;
            // 
            // guna2Elipse4
            // 
            guna2Elipse4.TargetControl = this;
            // 
            // guna2Elipse5
            // 
            guna2Elipse5.TargetControl = this;
            // 
            // frmDashBoard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(132, 122, 225);
            ClientSize = new Size(980, 628);
            Controls.Add(panelMoving);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(btnMinisize);
            Controls.Add(btnExit);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmDashBoard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "frmDashBoard";
            Load += frmDashBoard_Load;
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button btnExit;
        private Guna.UI2.WinForms.Guna2Button btnMinisize;
        private Panel panel1;
        private Guna.UI2.WinForms.Guna2Button btnAddRoom;
        private Panel panel2;
        private Guna.UI2.WinForms.Guna2Panel panelMoving;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private AllUser.UC_AddRoom uC_AddRoom1;
        private Guna.UI2.WinForms.Guna2Button btnCusRegister;
        private Guna.UI2.WinForms.Guna2Button btnCheckout;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private AllUser.UC_Register uC_Register1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
        private AllUser.UC_Checkout uC_Checkout1;
        private Guna.UI2.WinForms.Guna2Button btnCustomerDetails;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse4;
        private AllUser.UC_CustomerDetail uC_CustomerDetail1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse5;
        private Guna.UI2.WinForms.Guna2Button btnMangeEmployee;
        private AllUser.UC_Employees uC_Employees1;
    }
}