﻿using DataAccess.DAOs;
using DataAccess.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManagerHotelApp.AllUser
{
    public partial class UC_Register : UserControl
    {
        public UC_Register()
        {
            InitializeComponent();
        }

        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                string firstName = txtFirstName.Text;
                string lastName = txtLastName.Text;
                string phone = txtPhone.Text;
                string email = txtEmail.Text;
                string address = txtAddress.Text;
                string gender = cboGender.SelectedItem?.ToString();
                DateTime dob = dtpDob.Value;
                DateTime checkin = dtpCheckin.Value;
                string cccd = txtCCCD.Text;
                string roomNo = cboRoomNo.Text;

                Customer newCustomer = new Customer()
                {
                    FirstName = firstName,
                    LastName = lastName,
                    Phone = phone,
                    Email = email,
                    Address = address,
                    Gender = gender,
                    DateOfBrith = dob,
                    Cccd = cccd,
                };
                CustomerDAO customerDAO = new CustomerDAO();
                if (customerDAO.AddNewCustomer(newCustomer))
                {

                    int roomId = GetRoomIdByRoomNo(roomNo);
                    Booking newBooking = new Booking()
                    {
                        CustomerId = newCustomer.CustomerId,
                        RoomId = roomId,
                        CheckInDate = checkin,
                        CheckOutDate = null
                    };
                    BookingDAO bookingDAO = new BookingDAO();
                    if (bookingDAO.AddBooking(newBooking))
                    {
                        RoomDAO roomDAO = new RoomDAO();
                        roomDAO.UpdateRoomBookedStatus(roomNo, "YES");

                        ClearAll();

                        MessageBox.Show("Customer added successfully and room booked.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Failed to add booking.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Failed to add customer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cboRoomType_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedRoomType = cboRoomType.Text;
            RoomDAO roomDAO = new RoomDAO();
            List<string> roomNos = roomDAO.GetAvailableRoomNos(selectedRoomType);
            cboRoomNo.DataSource = roomNos;
        }

        private void cboRoomNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedRoomNo = cboRoomNo.Text;
            RoomDAO roomDAO = new RoomDAO();
            Room selectedRoom = roomDAO.GetRoomByRoomNo(selectedRoomNo);
            if (selectedRoom != null)
            {
                txtPrice.Text = selectedRoom.Price.ToString();
            }
            else
            {
                txtPrice.Text = "";
            }
        }

        private int GetRoomIdByRoomNo(string roomNo)
        {
            RoomDAO roomDAO = new RoomDAO();
            Room room = roomDAO.GetRoomByRoomNo(roomNo);
            if (room != null)
            {
                return room.RoomId;
            }
            throw new Exception($"Room with No: {roomNo} not found.");
        }

        public void ClearAll()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtPhone.Clear();
            txtAddress.Clear();
            cboGender.SelectedIndex = -1;
            dtpCheckin.ResetText();
            dtpDob.ResetText();
            txtCCCD.Clear();
            txtAddress.Clear();
            cboRoomType.SelectedIndex = -1;
            cboRoomNo.SelectedIndex = -1;
            txtPrice.Clear();
        }

        private void UC_Register_Leave(object sender, EventArgs e)
        {
            ClearAll();
        }
    }
}
