﻿namespace ManagerHotelApp.AllUser
{
    partial class UC_CustomerDetail
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            label1 = new Label();
            txtSearch = new Guna.UI2.WinForms.Guna2ComboBox();
            dgvListCustomer = new DataGridView();
            label2 = new Label();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            ((System.ComponentModel.ISupportInitialize)dgvListCustomer).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(18, 25);
            label1.Name = "label1";
            label1.Size = new Size(209, 28);
            label1.TabIndex = 15;
            label1.Text = "Customer Details";
            // 
            // txtSearch
            // 
            txtSearch.BackColor = Color.Transparent;
            txtSearch.CustomizableEdges = customizableEdges1;
            txtSearch.DrawMode = DrawMode.OwnerDrawFixed;
            txtSearch.DropDownStyle = ComboBoxStyle.DropDownList;
            txtSearch.FocusedColor = Color.FromArgb(94, 148, 255);
            txtSearch.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSearch.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            txtSearch.ForeColor = Color.Black;
            txtSearch.ItemHeight = 25;
            txtSearch.Items.AddRange(new object[] { "All Customer Details", "In Hotel Customer ", "Checkout Customer" });
            txtSearch.Location = new Point(579, 88);
            txtSearch.Name = "txtSearch";
            txtSearch.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtSearch.Size = new Size(259, 31);
            txtSearch.TabIndex = 17;
            txtSearch.SelectedIndexChanged += txtSearch_SelectedIndexChanged;
            // 
            // dgvListCustomer
            // 
            dgvListCustomer.BackgroundColor = SystemColors.ButtonFace;
            dgvListCustomer.BorderStyle = BorderStyle.Fixed3D;
            dgvListCustomer.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvListCustomer.Location = new Point(38, 145);
            dgvListCustomer.Name = "dgvListCustomer";
            dgvListCustomer.RowTemplate.Height = 25;
            dgvListCustomer.Size = new Size(819, 253);
            dgvListCustomer.TabIndex = 18;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(579, 65);
            label2.Name = "label2";
            label2.Size = new Size(60, 20);
            label2.TabIndex = 19;
            label2.Text = "Search";
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.BorderRadius = 30;
            guna2Elipse1.TargetControl = this;
            // 
            // UC_CustomerDetail
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(label2);
            Controls.Add(dgvListCustomer);
            Controls.Add(txtSearch);
            Controls.Add(label1);
            Name = "UC_CustomerDetail";
            Size = new Size(895, 477);
            Load += UC_CustomerDetail_Load;
            ((System.ComponentModel.ISupportInitialize)dgvListCustomer).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Guna.UI2.WinForms.Guna2ComboBox txtSearch;
        private DataGridView dgvListCustomer;
        private Label label2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
    }
}
