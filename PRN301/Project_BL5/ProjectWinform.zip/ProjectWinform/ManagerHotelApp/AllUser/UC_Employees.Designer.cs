﻿namespace ManagerHotelApp.AllUser
{
    partial class UC_Employees
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            label1 = new Label();
            tabEmployee = new TabControl();
            tabPage1 = new TabPage();
            btnAddEmployee = new Guna.UI2.WinForms.Guna2Button();
            cboPosition = new Guna.UI2.WinForms.Guna2ComboBox();
            label11 = new Label();
            txtSalary = new Guna.UI2.WinForms.Guna2TextBox();
            label9 = new Label();
            txtPassword = new Guna.UI2.WinForms.Guna2TextBox();
            label8 = new Label();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            label10 = new Label();
            txtAddress = new Guna.UI2.WinForms.Guna2TextBox();
            label7 = new Label();
            txtPhone = new Guna.UI2.WinForms.Guna2TextBox();
            label6 = new Label();
            txtLastName = new Guna.UI2.WinForms.Guna2TextBox();
            label4 = new Label();
            txtFirstName = new Guna.UI2.WinForms.Guna2TextBox();
            label5 = new Label();
            tabPage2 = new TabPage();
            dgvListDetails = new DataGridView();
            label3 = new Label();
            tabPage3 = new TabPage();
            btnUpdate = new Guna.UI2.WinForms.Guna2Button();
            txtPosition = new Guna.UI2.WinForms.Guna2TextBox();
            label14 = new Label();
            txtAddress1 = new Guna.UI2.WinForms.Guna2TextBox();
            label13 = new Label();
            txtPhoneNumber = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            btnDelete = new Guna.UI2.WinForms.Guna2Button();
            dgvListEmployee = new DataGridView();
            txtName = new Guna.UI2.WinForms.Guna2TextBox();
            label12 = new Label();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            reportEmp = new Guna.UI2.WinForms.Guna2Button();
            tabEmployee.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvListDetails).BeginInit();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvListEmployee).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(16, 19);
            label1.Name = "label1";
            label1.Size = new Size(234, 28);
            label1.TabIndex = 16;
            label1.Text = "Manage Employee";
            // 
            // tabEmployee
            // 
            tabEmployee.Controls.Add(tabPage1);
            tabEmployee.Controls.Add(tabPage2);
            tabEmployee.Controls.Add(tabPage3);
            tabEmployee.Cursor = Cursors.Hand;
            tabEmployee.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tabEmployee.Location = new Point(16, 72);
            tabEmployee.Name = "tabEmployee";
            tabEmployee.SelectedIndex = 0;
            tabEmployee.Size = new Size(859, 388);
            tabEmployee.TabIndex = 17;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(btnAddEmployee);
            tabPage1.Controls.Add(cboPosition);
            tabPage1.Controls.Add(label11);
            tabPage1.Controls.Add(txtSalary);
            tabPage1.Controls.Add(label9);
            tabPage1.Controls.Add(txtPassword);
            tabPage1.Controls.Add(label8);
            tabPage1.Controls.Add(txtEmail);
            tabPage1.Controls.Add(label10);
            tabPage1.Controls.Add(txtAddress);
            tabPage1.Controls.Add(label7);
            tabPage1.Controls.Add(txtPhone);
            tabPage1.Controls.Add(label6);
            tabPage1.Controls.Add(txtLastName);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(txtFirstName);
            tabPage1.Controls.Add(label5);
            tabPage1.ForeColor = Color.Black;
            tabPage1.Location = new Point(4, 26);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(851, 358);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Register Employee";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnAddEmployee
            // 
            btnAddEmployee.BorderRadius = 12;
            btnAddEmployee.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            btnAddEmployee.BorderThickness = 1;
            btnAddEmployee.CheckedState.FillColor = Color.FromArgb(0, 118, 221);
            btnAddEmployee.CheckedState.ForeColor = Color.White;
            btnAddEmployee.CustomizableEdges = customizableEdges1;
            btnAddEmployee.DisabledState.BorderColor = Color.DarkGray;
            btnAddEmployee.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAddEmployee.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAddEmployee.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAddEmployee.FillColor = Color.White;
            btnAddEmployee.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnAddEmployee.ForeColor = Color.Black;
            btnAddEmployee.Location = new Point(649, 260);
            btnAddEmployee.Name = "btnAddEmployee";
            btnAddEmployee.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnAddEmployee.Size = new Size(180, 53);
            btnAddEmployee.TabIndex = 120;
            btnAddEmployee.Text = "Add Employee";
            btnAddEmployee.Click += btnAddEmployee_Click;
            // 
            // cboPosition
            // 
            cboPosition.BackColor = Color.Transparent;
            cboPosition.CustomizableEdges = customizableEdges3;
            cboPosition.DrawMode = DrawMode.OwnerDrawFixed;
            cboPosition.DropDownStyle = ComboBoxStyle.DropDownList;
            cboPosition.FocusedColor = Color.FromArgb(94, 148, 255);
            cboPosition.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cboPosition.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cboPosition.ForeColor = Color.Black;
            cboPosition.ItemHeight = 30;
            cboPosition.Items.AddRange(new object[] { "Receptionist", "Guard", "Housekeeper", "Chef" });
            cboPosition.Location = new Point(603, 60);
            cboPosition.Name = "cboPosition";
            cboPosition.ShadowDecoration.CustomizableEdges = customizableEdges4;
            cboPosition.Size = new Size(242, 36);
            cboPosition.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            cboPosition.TabIndex = 119;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label11.Location = new Point(603, 40);
            label11.Name = "label11";
            label11.Size = new Size(51, 17);
            label11.TabIndex = 118;
            label11.Text = "Position";
            // 
            // txtSalary
            // 
            txtSalary.CustomizableEdges = customizableEdges5;
            txtSalary.DefaultText = "";
            txtSalary.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSalary.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSalary.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSalary.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSalary.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSalary.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtSalary.ForeColor = Color.Black;
            txtSalary.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSalary.Location = new Point(603, 147);
            txtSalary.Name = "txtSalary";
            txtSalary.PasswordChar = '\0';
            txtSalary.PlaceholderText = "Enter salary";
            txtSalary.SelectedText = "";
            txtSalary.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtSalary.Size = new Size(242, 32);
            txtSalary.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtSalary.TabIndex = 117;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label9.Location = new Point(603, 118);
            label9.Name = "label9";
            label9.Size = new Size(42, 17);
            label9.TabIndex = 116;
            label9.Text = "Salary";
            // 
            // txtPassword
            // 
            txtPassword.CustomizableEdges = customizableEdges7;
            txtPassword.DefaultText = "";
            txtPassword.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPassword.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPassword.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPassword.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPassword.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPassword.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtPassword.ForeColor = Color.Black;
            txtPassword.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPassword.Location = new Point(322, 223);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '\0';
            txtPassword.PlaceholderText = "Enter password";
            txtPassword.SelectedText = "";
            txtPassword.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtPassword.Size = new Size(242, 32);
            txtPassword.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtPassword.TabIndex = 115;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label8.Location = new Point(322, 194);
            label8.Name = "label8";
            label8.Size = new Size(60, 17);
            label8.TabIndex = 114;
            label8.Text = "Password";
            // 
            // txtEmail
            // 
            txtEmail.CustomizableEdges = customizableEdges9;
            txtEmail.DefaultText = "";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtEmail.ForeColor = Color.Black;
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(322, 147);
            txtEmail.Name = "txtEmail";
            txtEmail.PasswordChar = '\0';
            txtEmail.PlaceholderText = "Enter email";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtEmail.Size = new Size(242, 32);
            txtEmail.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtEmail.TabIndex = 113;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label10.Location = new Point(322, 118);
            label10.Name = "label10";
            label10.Size = new Size(38, 17);
            label10.TabIndex = 112;
            label10.Text = "Email";
            // 
            // txtAddress
            // 
            txtAddress.CustomizableEdges = customizableEdges11;
            txtAddress.DefaultText = "";
            txtAddress.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtAddress.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtAddress.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtAddress.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtAddress.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddress.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtAddress.ForeColor = Color.Black;
            txtAddress.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddress.Location = new Point(322, 64);
            txtAddress.Name = "txtAddress";
            txtAddress.PasswordChar = '\0';
            txtAddress.PlaceholderText = "Enter address";
            txtAddress.SelectedText = "";
            txtAddress.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtAddress.Size = new Size(242, 32);
            txtAddress.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtAddress.TabIndex = 111;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label7.Location = new Point(322, 35);
            label7.Name = "label7";
            label7.Size = new Size(51, 17);
            label7.TabIndex = 110;
            label7.Text = "Address";
            // 
            // txtPhone
            // 
            txtPhone.CustomizableEdges = customizableEdges13;
            txtPhone.DefaultText = "";
            txtPhone.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPhone.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPhone.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPhone.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPhone.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhone.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtPhone.ForeColor = Color.Black;
            txtPhone.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhone.Location = new Point(13, 223);
            txtPhone.Name = "txtPhone";
            txtPhone.PasswordChar = '\0';
            txtPhone.PlaceholderText = "Enter phone number";
            txtPhone.SelectedText = "";
            txtPhone.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtPhone.Size = new Size(242, 32);
            txtPhone.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtPhone.TabIndex = 96;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label6.Location = new Point(13, 194);
            label6.Name = "label6";
            label6.Size = new Size(89, 17);
            label6.TabIndex = 95;
            label6.Text = "Phone number";
            // 
            // txtLastName
            // 
            txtLastName.CustomizableEdges = customizableEdges15;
            txtLastName.DefaultText = "";
            txtLastName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtLastName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtLastName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtLastName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtLastName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtLastName.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtLastName.ForeColor = Color.Black;
            txtLastName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtLastName.Location = new Point(13, 142);
            txtLastName.Name = "txtLastName";
            txtLastName.PasswordChar = '\0';
            txtLastName.PlaceholderText = "Enter last name";
            txtLastName.SelectedText = "";
            txtLastName.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtLastName.Size = new Size(242, 32);
            txtLastName.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtLastName.TabIndex = 94;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label4.Location = new Point(13, 110);
            label4.Name = "label4";
            label4.Size = new Size(68, 17);
            label4.TabIndex = 93;
            label4.Text = "Last Name";
            // 
            // txtFirstName
            // 
            txtFirstName.CustomizableEdges = customizableEdges17;
            txtFirstName.DefaultText = "";
            txtFirstName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtFirstName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtFirstName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtFirstName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtFirstName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFirstName.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtFirstName.ForeColor = Color.Black;
            txtFirstName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFirstName.Location = new Point(13, 64);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.PasswordChar = '\0';
            txtFirstName.PlaceholderText = "Enter first name";
            txtFirstName.SelectedText = "";
            txtFirstName.ShadowDecoration.CustomizableEdges = customizableEdges18;
            txtFirstName.Size = new Size(242, 32);
            txtFirstName.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtFirstName.TabIndex = 92;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label5.Location = new Point(13, 35);
            label5.Name = "label5";
            label5.Size = new Size(69, 17);
            label5.TabIndex = 91;
            label5.Text = "First Name";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(reportEmp);
            tabPage2.Controls.Add(dgvListDetails);
            tabPage2.Controls.Add(label3);
            tabPage2.Location = new Point(4, 26);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(851, 358);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Employee Details";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // dgvListDetails
            // 
            dgvListDetails.BackgroundColor = SystemColors.ButtonFace;
            dgvListDetails.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvListDetails.Location = new Point(17, 60);
            dgvListDetails.Name = "dgvListDetails";
            dgvListDetails.RowTemplate.Height = 25;
            dgvListDetails.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvListDetails.Size = new Size(801, 259);
            dgvListDetails.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(17, 18);
            label3.Name = "label3";
            label3.Size = new Size(170, 23);
            label3.TabIndex = 1;
            label3.Text = "Employee Details";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(btnUpdate);
            tabPage3.Controls.Add(txtPosition);
            tabPage3.Controls.Add(label14);
            tabPage3.Controls.Add(txtAddress1);
            tabPage3.Controls.Add(label13);
            tabPage3.Controls.Add(txtPhoneNumber);
            tabPage3.Controls.Add(label2);
            tabPage3.Controls.Add(btnDelete);
            tabPage3.Controls.Add(dgvListEmployee);
            tabPage3.Controls.Add(txtName);
            tabPage3.Controls.Add(label12);
            tabPage3.Location = new Point(4, 26);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(851, 358);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Manger Employee";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            btnUpdate.BorderRadius = 12;
            btnUpdate.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            btnUpdate.BorderThickness = 1;
            btnUpdate.CheckedState.FillColor = Color.FromArgb(0, 118, 221);
            btnUpdate.CheckedState.ForeColor = Color.Red;
            btnUpdate.CustomizableEdges = customizableEdges21;
            btnUpdate.DisabledState.BorderColor = Color.DarkGray;
            btnUpdate.DisabledState.CustomBorderColor = Color.DarkGray;
            btnUpdate.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnUpdate.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnUpdate.FillColor = Color.White;
            btnUpdate.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnUpdate.ForeColor = Color.Black;
            btnUpdate.Location = new Point(33, 317);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.ShadowDecoration.CustomizableEdges = customizableEdges22;
            btnUpdate.Size = new Size(112, 35);
            btnUpdate.TabIndex = 128;
            btnUpdate.Text = "Update ";
            btnUpdate.Click += btnUpdate_Click;
            // 
            // txtPosition
            // 
            txtPosition.CustomizableEdges = customizableEdges23;
            txtPosition.DefaultText = "";
            txtPosition.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPosition.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPosition.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPosition.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPosition.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPosition.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtPosition.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPosition.Location = new Point(358, 77);
            txtPosition.Name = "txtPosition";
            txtPosition.PasswordChar = '\0';
            txtPosition.PlaceholderText = "";
            txtPosition.SelectedText = "";
            txtPosition.ShadowDecoration.CustomizableEdges = customizableEdges24;
            txtPosition.Size = new Size(120, 25);
            txtPosition.TabIndex = 127;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label14.Location = new Point(289, 77);
            label14.Name = "label14";
            label14.Size = new Size(63, 18);
            label14.TabIndex = 126;
            label14.Text = "Position";
            // 
            // txtAddress1
            // 
            txtAddress1.CustomizableEdges = customizableEdges25;
            txtAddress1.DefaultText = "";
            txtAddress1.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtAddress1.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtAddress1.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtAddress1.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtAddress1.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddress1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtAddress1.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddress1.Location = new Point(122, 77);
            txtAddress1.Name = "txtAddress1";
            txtAddress1.PasswordChar = '\0';
            txtAddress1.PlaceholderText = "";
            txtAddress1.SelectedText = "";
            txtAddress1.ShadowDecoration.CustomizableEdges = customizableEdges26;
            txtAddress1.Size = new Size(120, 25);
            txtAddress1.TabIndex = 125;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label13.Location = new Point(50, 77);
            label13.Name = "label13";
            label13.Size = new Size(66, 18);
            label13.TabIndex = 124;
            label13.Text = "Address";
            // 
            // txtPhoneNumber
            // 
            txtPhoneNumber.CustomizableEdges = customizableEdges27;
            txtPhoneNumber.DefaultText = "";
            txtPhoneNumber.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPhoneNumber.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPhoneNumber.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPhoneNumber.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPhoneNumber.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhoneNumber.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtPhoneNumber.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhoneNumber.Location = new Point(358, 31);
            txtPhoneNumber.Name = "txtPhoneNumber";
            txtPhoneNumber.PasswordChar = '\0';
            txtPhoneNumber.PlaceholderText = "";
            txtPhoneNumber.SelectedText = "";
            txtPhoneNumber.ShadowDecoration.CustomizableEdges = customizableEdges28;
            txtPhoneNumber.Size = new Size(120, 25);
            txtPhoneNumber.TabIndex = 123;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(289, 31);
            label2.Name = "label2";
            label2.Size = new Size(54, 18);
            label2.TabIndex = 122;
            label2.Text = "Phone";
            // 
            // btnDelete
            // 
            btnDelete.BorderRadius = 12;
            btnDelete.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            btnDelete.BorderThickness = 1;
            btnDelete.CheckedState.FillColor = Color.FromArgb(0, 118, 221);
            btnDelete.CheckedState.ForeColor = Color.Red;
            btnDelete.CustomizableEdges = customizableEdges29;
            btnDelete.DisabledState.BorderColor = Color.DarkGray;
            btnDelete.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDelete.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDelete.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDelete.FillColor = Color.White;
            btnDelete.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnDelete.ForeColor = Color.Black;
            btnDelete.Location = new Point(516, 67);
            btnDelete.Name = "btnDelete";
            btnDelete.ShadowDecoration.CustomizableEdges = customizableEdges30;
            btnDelete.Size = new Size(112, 35);
            btnDelete.TabIndex = 121;
            btnDelete.Text = "Delete";
            btnDelete.Click += btnDelete_Click;
            // 
            // dgvListEmployee
            // 
            dgvListEmployee.BorderStyle = BorderStyle.Fixed3D;
            dgvListEmployee.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvListEmployee.Location = new Point(33, 124);
            dgvListEmployee.Name = "dgvListEmployee";
            dgvListEmployee.RowTemplate.Height = 25;
            dgvListEmployee.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvListEmployee.Size = new Size(795, 184);
            dgvListEmployee.TabIndex = 3;
            dgvListEmployee.CellClick += dgvListEmployee_CellClick;
            // 
            // txtName
            // 
            txtName.CustomizableEdges = customizableEdges31;
            txtName.DefaultText = "";
            txtName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Location = new Point(122, 31);
            txtName.Name = "txtName";
            txtName.PasswordChar = '\0';
            txtName.PlaceholderText = "";
            txtName.SelectedText = "";
            txtName.ShadowDecoration.CustomizableEdges = customizableEdges32;
            txtName.Size = new Size(120, 25);
            txtName.TabIndex = 2;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label12.Location = new Point(51, 31);
            label12.Name = "label12";
            label12.Size = new Size(53, 18);
            label12.TabIndex = 1;
            label12.Text = "Name";
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.BorderRadius = 30;
            guna2Elipse1.TargetControl = this;
            // 
            // reportEmp
            // 
            reportEmp.BorderRadius = 12;
            reportEmp.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            reportEmp.BorderThickness = 1;
            reportEmp.CheckedState.FillColor = Color.FromArgb(0, 118, 221);
            reportEmp.CheckedState.ForeColor = Color.White;
            reportEmp.CustomizableEdges = customizableEdges19;
            reportEmp.DisabledState.BorderColor = Color.DarkGray;
            reportEmp.DisabledState.CustomBorderColor = Color.DarkGray;
            reportEmp.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            reportEmp.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            reportEmp.FillColor = Color.White;
            reportEmp.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            reportEmp.ForeColor = Color.Black;
            reportEmp.Location = new Point(684, 325);
            reportEmp.Name = "reportEmp";
            reportEmp.ShadowDecoration.CustomizableEdges = customizableEdges20;
            reportEmp.Size = new Size(134, 27);
            reportEmp.TabIndex = 121;
            reportEmp.Text = "Report";
            reportEmp.Click += reportEmp_Click;
            // 
            // UC_Employees
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(tabEmployee);
            Controls.Add(label1);
            Name = "UC_Employees";
            Size = new Size(895, 477);
            Load += UC_Employees_Load;
            tabEmployee.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvListDetails).EndInit();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvListEmployee).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TabControl tabEmployee;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private Guna.UI2.WinForms.Guna2TextBox txtLastName;
        private Label label4;
        private Guna.UI2.WinForms.Guna2TextBox txtFirstName;
        private Label label5;
        private Guna.UI2.WinForms.Guna2TextBox txtPhone;
        private Label label6;
        private Guna.UI2.WinForms.Guna2TextBox txtPassword;
        private Label label8;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Label label10;
        private Guna.UI2.WinForms.Guna2TextBox txtAddress;
        private Label label7;
        private Guna.UI2.WinForms.Guna2TextBox txtSalary;
        private Label label9;
        private Guna.UI2.WinForms.Guna2ComboBox cboPosition;
        private Label label11;
        private Guna.UI2.WinForms.Guna2Button btnAddEmployee;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private DataGridView dgvListDetails;
        private Label label3;
        private DataGridView dgvListEmployee;
        private Guna.UI2.WinForms.Guna2TextBox txtName;
        private Guna.UI2.WinForms.Guna2Button btnDelete;
        private Label label12;
        private Guna.UI2.WinForms.Guna2TextBox txtPosition;
        private Label label14;
        private Guna.UI2.WinForms.Guna2TextBox txtAddress1;
        private Label label13;
        private Guna.UI2.WinForms.Guna2TextBox txtPhoneNumber;
        private Label label2;
        private Guna.UI2.WinForms.Guna2Button btnUpdate;
        private Guna.UI2.WinForms.Guna2Button reportEmp;
    }
}
