﻿using DataAccess.DAOs;
using DataAccess.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManagerHotelApp.AllUser
{
    public partial class UC_Checkout : UserControl
    {
        public UC_Checkout()
        {
            InitializeComponent();
            loadcheckout();
            ShowCustomersWithBookingsByRoomStatus("YES");
        }

        private void loadcheckout()
        {
            dgvCheckoutList.ColumnCount = 7; // Adjust the number of columns based on your data

            dgvCheckoutList.Columns[0].Name = "CustomerName";
            dgvCheckoutList.Columns[0].HeaderText = "Customer Name";

            dgvCheckoutList.Columns[1].Name = "Phone";
            dgvCheckoutList.Columns[1].HeaderText = "Phone Number";

            dgvCheckoutList.Columns[2].Name = "Cccd";
            dgvCheckoutList.Columns[2].HeaderText = "CCCD/CMT";

            dgvCheckoutList.Columns[3].Name = "DateOfBrith";
            dgvCheckoutList.Columns[3].HeaderText = "DateOfBrith";

            dgvCheckoutList.Columns[4].Name = "CheckInDate";
            dgvCheckoutList.Columns[4].HeaderText = "Check-In Date";

            dgvCheckoutList.Columns[5].Name = "RoomName";
            dgvCheckoutList.Columns[5].HeaderText = "Room Name";

            dgvCheckoutList.Columns[6].Name = "RoomType";
            dgvCheckoutList.Columns[6].HeaderText = "Room Type";
        }
        private void ShowAllCustomersWithBookings()
        {
            CustomerDAO customerDAO = new CustomerDAO();
            List<Customer> customerss = customerDAO.GetAllCustomersWithBookings();
            foreach (var customer in customerss)
            {
                foreach (var booking in customer.Bookings)
                {
                    dgvCheckoutList.Rows.Add(
                        customer.FirstName + " " + customer.LastName,
                        customer.Phone,
                        customer.Cccd,
                        customer.DateOfBrith?.ToShortDateString(),
                        booking.CheckInDate?.ToShortDateString(),
                        booking.Room?.RoomName,
                        booking.Room?.RoomType
                    );
                }
            }

        }
        private void ShowCustomersWithBookingsByRoomStatus(string roomStatus)
        {
            CustomerDAO customerDAO = new CustomerDAO();
            List<Customer> customerss = customerDAO.GetCustomersWithBookingsByRoomStatus(roomStatus);

            foreach (var customer in customerss)
            {
                foreach (var booking in customer.Bookings)
                {
                    if (booking.Room != null && booking.Room.Status == roomStatus)
                    {
                        dgvCheckoutList.Rows.Add(
                        customer.FirstName + " " + customer.LastName,
                        customer.Phone,
                        customer.Cccd,
                        customer.DateOfBrith?.ToShortDateString(),
                        booking.CheckInDate?.ToShortDateString(),
                        booking.Room?.RoomName,
                        booking.Room?.RoomType
                        );
                    }
                }
            }
        }

        private void txtSearchName_TextChanged(object sender, EventArgs e)
        {


            string searchName = txtSearchName.Text.Trim();
            CustomerDAO customerDAO = new CustomerDAO();
            List<Customer> filteredCustomers = customerDAO.SearchCusByName(searchName);

            foreach (var customer in filteredCustomers)
            {
                foreach (var booking in customer.Bookings)
                {
                    dgvCheckoutList.Rows.Add(
                        customer.FirstName + " " + customer.LastName,
                        customer.Phone,
                        customer.Cccd,
                        customer.DateOfBrith?.ToShortDateString(),
                        booking.CheckInDate?.ToShortDateString(),
                        booking.Room?.RoomName,
                        booking.Room?.RoomType
                    );
                }
            }
            dgvCheckoutList.DataSource = filteredCustomers;

        }

        private void dgvCheckoutList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Lấy ra hàng được chọn
                DataGridViewRow selectedRow = dgvCheckoutList.Rows[e.RowIndex];

                // Hiển thị thông tin của hàng được chọn
                txtCName.Text = Convert.ToString(selectedRow.Cells["CustomerName"].Value);
                txtRoom.Text = Convert.ToString(selectedRow.Cells["RoomName"].Value);
            }
        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            if (dgvCheckoutList.SelectedRows.Count > 0)
            {
                // Lấy hàng đầu tiên được chọn
                DataGridViewRow selectedRow = dgvCheckoutList.SelectedRows[0];

                // Lấy ra thông tin cần thiết từ hàng được chọn
                string roomName = Convert.ToString(selectedRow.Cells["RoomName"].Value);

                try
                {
                    // Thực hiện cập nhật trạng thái của phòng trong cơ sở dữ liệu
                    
                    RoomDAO roomDAO = new RoomDAO();
                    roomDAO.UpdateRoomBookedStatus(roomName, "NO");

                    // Xóa hàng đã chọn khỏi DataGridView
                    dgvCheckoutList.Rows.RemoveAt(selectedRow.Index);

                    // Xóa thông tin khách hàng và phòng đã chọn
                    txtCName.Text = "";
                    txtRoom.Text = "";
                    MessageBox.Show("Check out succesfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Failed to update room status: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Please select a booking to check out.");
            }
        }
    }
}
