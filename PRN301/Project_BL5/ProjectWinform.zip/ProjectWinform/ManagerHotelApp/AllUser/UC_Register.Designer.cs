﻿namespace ManagerHotelApp.AllUser
{
    partial class UC_Register
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            label10 = new Label();
            cboGender = new Guna.UI2.WinForms.Guna2ComboBox();
            label5 = new Label();
            btnAddCustomer = new Guna.UI2.WinForms.Guna2Button();
            txtPrice = new Guna.UI2.WinForms.Guna2TextBox();
            label13 = new Label();
            cboRoomNo = new Guna.UI2.WinForms.Guna2ComboBox();
            label12 = new Label();
            cboRoomType = new Guna.UI2.WinForms.Guna2ComboBox();
            label11 = new Label();
            dtpCheckin = new Guna.UI2.WinForms.Guna2DateTimePicker();
            label9 = new Label();
            txtAddress = new Guna.UI2.WinForms.Guna2TextBox();
            label7 = new Label();
            txtCCCD = new Guna.UI2.WinForms.Guna2TextBox();
            label8 = new Label();
            dtpDob = new Guna.UI2.WinForms.Guna2DateTimePicker();
            label6 = new Label();
            txtLastName = new Guna.UI2.WinForms.Guna2TextBox();
            label4 = new Label();
            txtPhone = new Guna.UI2.WinForms.Guna2TextBox();
            label3 = new Label();
            txtFirstName = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            label1 = new Label();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            SuspendLayout();
            // 
            // txtEmail
            // 
            txtEmail.CustomizableEdges = customizableEdges1;
            txtEmail.DefaultText = "";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtEmail.ForeColor = Color.Black;
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(318, 261);
            txtEmail.Name = "txtEmail";
            txtEmail.PasswordChar = '\0';
            txtEmail.PlaceholderText = "Enter email";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtEmail.Size = new Size(242, 32);
            txtEmail.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtEmail.TabIndex = 109;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label10.Location = new Point(318, 232);
            label10.Name = "label10";
            label10.Size = new Size(38, 17);
            label10.TabIndex = 108;
            label10.Text = "Email";
            // 
            // cboGender
            // 
            cboGender.BackColor = Color.Transparent;
            cboGender.CustomizableEdges = customizableEdges3;
            cboGender.DrawMode = DrawMode.OwnerDrawFixed;
            cboGender.DropDownStyle = ComboBoxStyle.DropDownList;
            cboGender.FocusedColor = Color.FromArgb(94, 148, 255);
            cboGender.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cboGender.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cboGender.ForeColor = Color.Black;
            cboGender.ItemHeight = 30;
            cboGender.Items.AddRange(new object[] { "Male", "Female", "Other" });
            cboGender.Location = new Point(38, 333);
            cboGender.Name = "cboGender";
            cboGender.ShadowDecoration.CustomizableEdges = customizableEdges4;
            cboGender.Size = new Size(242, 36);
            cboGender.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            cboGender.TabIndex = 107;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label5.Location = new Point(38, 313);
            label5.Name = "label5";
            label5.Size = new Size(48, 17);
            label5.TabIndex = 106;
            label5.Text = "Gender";
            // 
            // btnAddCustomer
            // 
            btnAddCustomer.BorderRadius = 12;
            btnAddCustomer.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            btnAddCustomer.BorderThickness = 1;
            btnAddCustomer.CheckedState.FillColor = Color.FromArgb(0, 118, 221);
            btnAddCustomer.CheckedState.ForeColor = Color.White;
            btnAddCustomer.CustomizableEdges = customizableEdges5;
            btnAddCustomer.DisabledState.BorderColor = Color.DarkGray;
            btnAddCustomer.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAddCustomer.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAddCustomer.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAddCustomer.FillColor = Color.White;
            btnAddCustomer.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnAddCustomer.ForeColor = Color.Black;
            btnAddCustomer.Location = new Point(695, 393);
            btnAddCustomer.Name = "btnAddCustomer";
            btnAddCustomer.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnAddCustomer.Size = new Size(180, 53);
            btnAddCustomer.TabIndex = 105;
            btnAddCustomer.Text = "Add Customer";
            btnAddCustomer.Click += btnAddCustomer_Click;
            // 
            // txtPrice
            // 
            txtPrice.CustomizableEdges = customizableEdges7;
            txtPrice.DefaultText = "";
            txtPrice.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPrice.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPrice.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPrice.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPrice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPrice.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtPrice.ForeColor = Color.Black;
            txtPrice.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPrice.Location = new Point(597, 261);
            txtPrice.Name = "txtPrice";
            txtPrice.PasswordChar = '\0';
            txtPrice.PlaceholderText = "";
            txtPrice.ReadOnly = true;
            txtPrice.SelectedText = "";
            txtPrice.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtPrice.Size = new Size(242, 32);
            txtPrice.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtPrice.TabIndex = 104;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label13.Location = new Point(597, 232);
            label13.Name = "label13";
            label13.Size = new Size(35, 17);
            label13.TabIndex = 103;
            label13.Text = "Price";
            // 
            // cboRoomNo
            // 
            cboRoomNo.BackColor = Color.Transparent;
            cboRoomNo.CustomizableEdges = customizableEdges9;
            cboRoomNo.DrawMode = DrawMode.OwnerDrawFixed;
            cboRoomNo.DropDownStyle = ComboBoxStyle.DropDownList;
            cboRoomNo.FocusedColor = Color.FromArgb(94, 148, 255);
            cboRoomNo.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cboRoomNo.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cboRoomNo.ForeColor = Color.Black;
            cboRoomNo.ItemHeight = 30;
            cboRoomNo.Location = new Point(597, 178);
            cboRoomNo.Name = "cboRoomNo";
            cboRoomNo.ShadowDecoration.CustomizableEdges = customizableEdges10;
            cboRoomNo.Size = new Size(242, 36);
            cboRoomNo.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            cboRoomNo.TabIndex = 102;
            cboRoomNo.SelectedIndexChanged += cboRoomNo_SelectedIndexChanged;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label12.Location = new Point(597, 158);
            label12.Name = "label12";
            label12.Size = new Size(88, 17);
            label12.TabIndex = 101;
            label12.Text = "Room number";
            // 
            // cboRoomType
            // 
            cboRoomType.BackColor = Color.Transparent;
            cboRoomType.CustomizableEdges = customizableEdges11;
            cboRoomType.DrawMode = DrawMode.OwnerDrawFixed;
            cboRoomType.DropDownStyle = ComboBoxStyle.DropDownList;
            cboRoomType.FocusedColor = Color.FromArgb(94, 148, 255);
            cboRoomType.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cboRoomType.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cboRoomType.ForeColor = Color.Black;
            cboRoomType.ItemHeight = 30;
            cboRoomType.Items.AddRange(new object[] { "Single", "Double", "Couple", "Family", "Vip" });
            cboRoomType.Location = new Point(597, 98);
            cboRoomType.Name = "cboRoomType";
            cboRoomType.ShadowDecoration.CustomizableEdges = customizableEdges12;
            cboRoomType.Size = new Size(242, 36);
            cboRoomType.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            cboRoomType.TabIndex = 100;
            cboRoomType.SelectedIndexChanged += cboRoomType_SelectedIndexChanged;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label11.Location = new Point(597, 78);
            label11.Name = "label11";
            label11.Size = new Size(68, 17);
            label11.TabIndex = 99;
            label11.Text = "Room type";
            // 
            // dtpCheckin
            // 
            dtpCheckin.Checked = true;
            dtpCheckin.CustomizableEdges = customizableEdges13;
            dtpCheckin.FillColor = Color.FromArgb(0, 118, 221);
            dtpCheckin.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dtpCheckin.Format = DateTimePickerFormat.Long;
            dtpCheckin.Location = new Point(597, 333);
            dtpCheckin.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpCheckin.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpCheckin.Name = "dtpCheckin";
            dtpCheckin.ShadowDecoration.CustomizableEdges = customizableEdges14;
            dtpCheckin.Size = new Size(242, 33);
            dtpCheckin.TabIndex = 98;
            dtpCheckin.Value = new DateTime(2024, 4, 6, 15, 46, 32, 755);
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label9.Location = new Point(597, 313);
            label9.Name = "label9";
            label9.Size = new Size(55, 17);
            label9.TabIndex = 97;
            label9.Text = "Check in";
            // 
            // txtAddress
            // 
            txtAddress.CustomizableEdges = customizableEdges15;
            txtAddress.DefaultText = "";
            txtAddress.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtAddress.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtAddress.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtAddress.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtAddress.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddress.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtAddress.ForeColor = Color.Black;
            txtAddress.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddress.Location = new Point(318, 178);
            txtAddress.Name = "txtAddress";
            txtAddress.PasswordChar = '\0';
            txtAddress.PlaceholderText = "Enter address";
            txtAddress.SelectedText = "";
            txtAddress.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtAddress.Size = new Size(242, 32);
            txtAddress.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtAddress.TabIndex = 96;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label7.Location = new Point(318, 149);
            label7.Name = "label7";
            label7.Size = new Size(51, 17);
            label7.TabIndex = 95;
            label7.Text = "Address";
            // 
            // txtCCCD
            // 
            txtCCCD.CustomizableEdges = customizableEdges17;
            txtCCCD.DefaultText = "";
            txtCCCD.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCCCD.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCCCD.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCCCD.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCCCD.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCCCD.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtCCCD.ForeColor = Color.Black;
            txtCCCD.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCCCD.Location = new Point(318, 96);
            txtCCCD.Name = "txtCCCD";
            txtCCCD.PasswordChar = '\0';
            txtCCCD.PlaceholderText = "Enter ID";
            txtCCCD.SelectedText = "";
            txtCCCD.ShadowDecoration.CustomizableEdges = customizableEdges18;
            txtCCCD.Size = new Size(242, 32);
            txtCCCD.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtCCCD.TabIndex = 94;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label8.Location = new Point(318, 67);
            label8.Name = "label8";
            label8.Size = new Size(91, 17);
            label8.TabIndex = 93;
            label8.Text = "CCCD/CMTND";
            // 
            // dtpDob
            // 
            dtpDob.Checked = true;
            dtpDob.CustomizableEdges = customizableEdges19;
            dtpDob.FillColor = Color.FromArgb(0, 118, 221);
            dtpDob.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dtpDob.Format = DateTimePickerFormat.Long;
            dtpDob.Location = new Point(318, 336);
            dtpDob.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpDob.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpDob.Name = "dtpDob";
            dtpDob.ShadowDecoration.CustomizableEdges = customizableEdges20;
            dtpDob.Size = new Size(242, 33);
            dtpDob.TabIndex = 92;
            dtpDob.Value = new DateTime(2024, 4, 6, 15, 46, 32, 755);
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label6.Location = new Point(318, 311);
            label6.Name = "label6";
            label6.Size = new Size(79, 17);
            label6.TabIndex = 91;
            label6.Text = "Date of birth";
            // 
            // txtLastName
            // 
            txtLastName.CustomizableEdges = customizableEdges21;
            txtLastName.DefaultText = "";
            txtLastName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtLastName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtLastName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtLastName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtLastName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtLastName.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtLastName.ForeColor = Color.Black;
            txtLastName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtLastName.Location = new Point(38, 174);
            txtLastName.Name = "txtLastName";
            txtLastName.PasswordChar = '\0';
            txtLastName.PlaceholderText = "Enter last name";
            txtLastName.SelectedText = "";
            txtLastName.ShadowDecoration.CustomizableEdges = customizableEdges22;
            txtLastName.Size = new Size(242, 32);
            txtLastName.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtLastName.TabIndex = 90;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label4.Location = new Point(38, 142);
            label4.Name = "label4";
            label4.Size = new Size(68, 17);
            label4.TabIndex = 89;
            label4.Text = "Last Name";
            // 
            // txtPhone
            // 
            txtPhone.CustomizableEdges = customizableEdges23;
            txtPhone.DefaultText = "";
            txtPhone.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPhone.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPhone.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPhone.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPhone.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhone.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtPhone.ForeColor = Color.Black;
            txtPhone.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhone.Location = new Point(38, 258);
            txtPhone.Name = "txtPhone";
            txtPhone.PasswordChar = '\0';
            txtPhone.PlaceholderText = "Enter phone number";
            txtPhone.SelectedText = "";
            txtPhone.ShadowDecoration.CustomizableEdges = customizableEdges24;
            txtPhone.Size = new Size(242, 32);
            txtPhone.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtPhone.TabIndex = 88;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label3.Location = new Point(38, 229);
            label3.Name = "label3";
            label3.Size = new Size(89, 17);
            label3.TabIndex = 87;
            label3.Text = "Phone number";
            // 
            // txtFirstName
            // 
            txtFirstName.CustomizableEdges = customizableEdges25;
            txtFirstName.DefaultText = "";
            txtFirstName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtFirstName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtFirstName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtFirstName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtFirstName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFirstName.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtFirstName.ForeColor = Color.Black;
            txtFirstName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFirstName.Location = new Point(38, 96);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.PasswordChar = '\0';
            txtFirstName.PlaceholderText = "Enter first name";
            txtFirstName.SelectedText = "";
            txtFirstName.ShadowDecoration.CustomizableEdges = customizableEdges26;
            txtFirstName.Size = new Size(242, 32);
            txtFirstName.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtFirstName.TabIndex = 86;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(38, 67);
            label2.Name = "label2";
            label2.Size = new Size(69, 17);
            label2.TabIndex = 85;
            label2.Text = "First Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(20, 31);
            label1.Name = "label1";
            label1.Size = new Size(260, 28);
            label1.TabIndex = 84;
            label1.Text = "Customer registration";
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.BorderRadius = 30;
            guna2Elipse1.TargetControl = this;
            // 
            // UC_Register
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(txtEmail);
            Controls.Add(label10);
            Controls.Add(cboGender);
            Controls.Add(label5);
            Controls.Add(btnAddCustomer);
            Controls.Add(txtPrice);
            Controls.Add(label13);
            Controls.Add(cboRoomNo);
            Controls.Add(label12);
            Controls.Add(cboRoomType);
            Controls.Add(label11);
            Controls.Add(dtpCheckin);
            Controls.Add(label9);
            Controls.Add(txtAddress);
            Controls.Add(label7);
            Controls.Add(txtCCCD);
            Controls.Add(label8);
            Controls.Add(dtpDob);
            Controls.Add(label6);
            Controls.Add(txtLastName);
            Controls.Add(label4);
            Controls.Add(txtPhone);
            Controls.Add(label3);
            Controls.Add(txtFirstName);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "UC_Register";
            Size = new Size(895, 477);
            Leave += UC_Register_Leave;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Label label10;
        private Guna.UI2.WinForms.Guna2ComboBox cboGender;
        private Label label5;
        private Guna.UI2.WinForms.Guna2Button btnAddCustomer;
        private Guna.UI2.WinForms.Guna2TextBox txtPrice;
        private Label label13;
        private Guna.UI2.WinForms.Guna2ComboBox cboRoomNo;
        private Label label12;
        private Guna.UI2.WinForms.Guna2ComboBox cboRoomType;
        private Label label11;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpCheckin;
        private Label label9;
        private Guna.UI2.WinForms.Guna2TextBox txtAddress;
        private Label label7;
        private Guna.UI2.WinForms.Guna2TextBox txtCCCD;
        private Label label8;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpDob;
        private Label label6;
        private Guna.UI2.WinForms.Guna2TextBox txtLastName;
        private Label label4;
        private Guna.UI2.WinForms.Guna2TextBox txtPhone;
        private Label label3;
        private Guna.UI2.WinForms.Guna2TextBox txtFirstName;
        private Label label2;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
    }
}
