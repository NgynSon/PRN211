﻿using DataAccess.DAOs;
using DataAccess.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManagerHotelApp.AllUser
{
    public partial class UC_CustomerDetail : UserControl
    {
        public UC_CustomerDetail()
        {
            InitializeComponent();
            loadCustomer();
            txtSearch.SelectedItem = "All Customer Details";
        }

        private void loadCustomer()
        {
            dgvListCustomer.ColumnCount = 11; // Adjust the number of columns based on your data

            dgvListCustomer.Columns[0].Name = "CustomerName";
            dgvListCustomer.Columns[0].HeaderText = "Customer Name";

            dgvListCustomer.Columns[1].Name = "Phone";
            dgvListCustomer.Columns[1].HeaderText = "Phone Number";

            dgvListCustomer.Columns[2].Name = "Email";
            dgvListCustomer.Columns[2].HeaderText = "Email";

            dgvListCustomer.Columns[3].Name = "Address";
            dgvListCustomer.Columns[3].HeaderText = "Address";

            dgvListCustomer.Columns[4].Name = "Cccd";
            dgvListCustomer.Columns[4].HeaderText = "CCCD/CMT";

            dgvListCustomer.Columns[5].Name = "DateOfBrith";
            dgvListCustomer.Columns[5].HeaderText = "DateOfBrith";

            dgvListCustomer.Columns[6].Name = "Gender";
            dgvListCustomer.Columns[6].HeaderText = "Gender";

            dgvListCustomer.Columns[7].Name = "CheckInDate";
            dgvListCustomer.Columns[7].HeaderText = "Check-In Date";

            dgvListCustomer.Columns[8].Name = "CheckOutDate";
            dgvListCustomer.Columns[8].HeaderText = "Check-Out Date";

            dgvListCustomer.Columns[9].Name = "RoomName";
            dgvListCustomer.Columns[9].HeaderText = "Room Name";

            dgvListCustomer.Columns[10].Name = "RoomType";
            dgvListCustomer.Columns[10].HeaderText = "Room Type";
        }

        private void txtSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgvListCustomer.Rows.Clear();

            string selectedSearchOption = txtSearch.SelectedItem.ToString();

            switch (selectedSearchOption)
            {
                case "All Customer Details":
                    ShowAllCustomersWithBookings();
                    break;
                case "In Hotel Customer ":
                    ShowCustomersWithBookingsByRoomStatus("YES");
                    break;
                case "Checkout Customer":
                    ShowCustomersWithBookingsByRoomStatus("NO");
                    break;
                default:
                    // Handle unexpected or unsupported search options
                    MessageBox.Show("Invalid search option selected.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        private void ShowAllCustomersWithBookings()
        {
            CustomerDAO customerDAO = new CustomerDAO();
            List<Customer> customers = customerDAO.GetAllCustomersWithBookings();

            foreach (var customer in customers)
            {
                foreach (var booking in customer.Bookings)
                {
                    dgvListCustomer.Rows.Add(
                        customer.FirstName + " " + customer.LastName,
                        customer.Phone,
                        customer.Email,
                        customer.Address,
                        customer.Cccd,
                        customer.DateOfBrith?.ToShortDateString(),
                        customer.Gender,
                        booking.CheckInDate?.ToShortDateString(),
                        booking.CheckOutDate?.ToShortDateString(),
                        booking.Room?.RoomName,
                        booking.Room?.RoomType
                    );
                }
            }
        }
        private void ShowCustomersWithBookingsByRoomStatus(string roomStatus)
        {
            CustomerDAO customerDAO = new CustomerDAO();
            List<Customer> customers = customerDAO.GetCustomersWithBookingsByRoomStatus(roomStatus);

            foreach (var customer in customers)
            {
                foreach (var booking in customer.Bookings)
                {
                    if (booking.Room != null && booking.Room.Status == roomStatus)
                    {
                        dgvListCustomer.Rows.Add(
                            customer.FirstName + " " + customer.LastName,
                        customer.Phone,
                        customer.Email,
                        customer.Address,
                        customer.Cccd,
                        customer.DateOfBrith?.ToShortDateString(),
                        customer.Gender,
                        booking.CheckInDate?.ToShortDateString(),
                        booking.CheckOutDate?.ToShortDateString(),
                        booking.Room?.RoomName,
                        booking.Room?.RoomType
                        );
                    }
                }
            }
        }

        private void UC_CustomerDetail_Load(object sender, EventArgs e)
        {

        }
    }
}
