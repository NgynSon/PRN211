﻿namespace ManagerHotelApp.AllUser
{
    partial class UC_Checkout
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            dgvCheckoutList = new DataGridView();
            btnCheckOut = new Guna.UI2.WinForms.Guna2Button();
            dtpCheckoutDate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            dtbCheckoutDay = new Label();
            txtRoom = new Guna.UI2.WinForms.Guna2TextBox();
            label4 = new Label();
            txtCName = new Guna.UI2.WinForms.Guna2TextBox();
            label3 = new Label();
            txtSearchName = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            label1 = new Label();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            ((System.ComponentModel.ISupportInitialize)dgvCheckoutList).BeginInit();
            SuspendLayout();
            // 
            // dgvCheckoutList
            // 
            dgvCheckoutList.BackgroundColor = Color.White;
            dgvCheckoutList.BorderStyle = BorderStyle.Fixed3D;
            dgvCheckoutList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCheckoutList.Location = new Point(43, 147);
            dgvCheckoutList.Name = "dgvCheckoutList";
            dgvCheckoutList.RowTemplate.Height = 25;
            dgvCheckoutList.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCheckoutList.Size = new Size(763, 211);
            dgvCheckoutList.TabIndex = 66;
            dgvCheckoutList.CellClick += dgvCheckoutList_CellClick;
            // 
            // btnCheckOut
            // 
            btnCheckOut.BorderRadius = 12;
            btnCheckOut.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            btnCheckOut.BorderThickness = 1;
            btnCheckOut.CheckedState.FillColor = Color.FromArgb(0, 118, 221);
            btnCheckOut.CheckedState.ForeColor = Color.White;
            btnCheckOut.CustomizableEdges = customizableEdges1;
            btnCheckOut.DisabledState.BorderColor = Color.DarkGray;
            btnCheckOut.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCheckOut.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCheckOut.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCheckOut.FillColor = Color.White;
            btnCheckOut.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnCheckOut.ForeColor = Color.Black;
            btnCheckOut.Location = new Point(756, 398);
            btnCheckOut.Name = "btnCheckOut";
            btnCheckOut.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnCheckOut.Size = new Size(129, 44);
            btnCheckOut.TabIndex = 65;
            btnCheckOut.Text = "Check Out";
            btnCheckOut.Click += btnCheckOut_Click;
            // 
            // dtpCheckoutDate
            // 
            dtpCheckoutDate.Checked = true;
            dtpCheckoutDate.CustomizableEdges = customizableEdges3;
            dtpCheckoutDate.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dtpCheckoutDate.Format = DateTimePickerFormat.Long;
            dtpCheckoutDate.Location = new Point(473, 406);
            dtpCheckoutDate.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpCheckoutDate.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpCheckoutDate.Name = "dtpCheckoutDate";
            dtpCheckoutDate.ShadowDecoration.CustomizableEdges = customizableEdges4;
            dtpCheckoutDate.Size = new Size(182, 36);
            dtpCheckoutDate.TabIndex = 64;
            dtpCheckoutDate.Value = new DateTime(2024, 4, 7, 10, 16, 8, 294);
            // 
            // dtbCheckoutDay
            // 
            dtbCheckoutDay.AutoSize = true;
            dtbCheckoutDay.Font = new Font("Segoe UI", 11.25F, FontStyle.Italic, GraphicsUnit.Point);
            dtbCheckoutDay.Location = new Point(473, 383);
            dtbCheckoutDay.Name = "dtbCheckoutDay";
            dtbCheckoutDay.Size = new Size(101, 20);
            dtbCheckoutDay.TabIndex = 63;
            dtbCheckoutDay.Text = "Checkout date";
            // 
            // txtRoom
            // 
            txtRoom.CustomizableEdges = customizableEdges5;
            txtRoom.DefaultText = "";
            txtRoom.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtRoom.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtRoom.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtRoom.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtRoom.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRoom.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            txtRoom.ForeColor = Color.Black;
            txtRoom.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRoom.Location = new Point(252, 410);
            txtRoom.Name = "txtRoom";
            txtRoom.PasswordChar = '\0';
            txtRoom.PlaceholderText = "";
            txtRoom.ReadOnly = true;
            txtRoom.SelectedText = "";
            txtRoom.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtRoom.Size = new Size(200, 32);
            txtRoom.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtRoom.TabIndex = 62;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Italic, GraphicsUnit.Point);
            label4.Location = new Point(252, 379);
            label4.Name = "label4";
            label4.Size = new Size(100, 20);
            label4.TabIndex = 61;
            label4.Text = "Room number";
            // 
            // txtCName
            // 
            txtCName.CustomizableEdges = customizableEdges7;
            txtCName.DefaultText = "";
            txtCName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCName.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            txtCName.ForeColor = Color.Black;
            txtCName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCName.Location = new Point(33, 410);
            txtCName.Name = "txtCName";
            txtCName.PasswordChar = '\0';
            txtCName.PlaceholderText = "";
            txtCName.ReadOnly = true;
            txtCName.SelectedText = "";
            txtCName.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtCName.Size = new Size(200, 32);
            txtCName.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtCName.TabIndex = 60;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Italic, GraphicsUnit.Point);
            label3.Location = new Point(33, 379);
            label3.Name = "label3";
            label3.Size = new Size(48, 20);
            label3.TabIndex = 59;
            label3.Text = "Name";
            // 
            // txtSearchName
            // 
            txtSearchName.CustomizableEdges = customizableEdges9;
            txtSearchName.DefaultText = "";
            txtSearchName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSearchName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSearchName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSearchName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSearchName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSearchName.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            txtSearchName.ForeColor = Color.Black;
            txtSearchName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSearchName.Location = new Point(349, 109);
            txtSearchName.Name = "txtSearchName";
            txtSearchName.PasswordChar = '\0';
            txtSearchName.PlaceholderText = "Enter name";
            txtSearchName.SelectedText = "";
            txtSearchName.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtSearchName.Size = new Size(269, 32);
            txtSearchName.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtSearchName.TabIndex = 58;
            txtSearchName.TextChanged += txtSearchName_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(272, 121);
            label2.Name = "label2";
            label2.Size = new Size(51, 20);
            label2.TabIndex = 57;
            label2.Text = "Seacrh";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(9, 35);
            label1.Name = "label1";
            label1.Size = new Size(258, 28);
            label1.TabIndex = 56;
            label1.Text = "Reservation payment";
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.BorderRadius = 30;
            guna2Elipse1.TargetControl = this;
            // 
            // UC_Checkout
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(dgvCheckoutList);
            Controls.Add(btnCheckOut);
            Controls.Add(dtpCheckoutDate);
            Controls.Add(dtbCheckoutDay);
            Controls.Add(txtRoom);
            Controls.Add(label4);
            Controls.Add(txtCName);
            Controls.Add(label3);
            Controls.Add(txtSearchName);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "UC_Checkout";
            Size = new Size(895, 477);
            ((System.ComponentModel.ISupportInitialize)dgvCheckoutList).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvCheckoutList;
        private Guna.UI2.WinForms.Guna2Button btnCheckOut;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpCheckoutDate;
        private Label dtbCheckoutDay;
        private Guna.UI2.WinForms.Guna2TextBox txtRoom;
        private Label label4;
        private Guna.UI2.WinForms.Guna2TextBox txtCName;
        private Label label3;
        private Guna.UI2.WinForms.Guna2TextBox txtSearchName;
        private Label label2;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
    }
}
