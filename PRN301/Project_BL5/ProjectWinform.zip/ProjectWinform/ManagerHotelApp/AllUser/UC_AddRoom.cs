﻿using DataAccess.DAOs;
using DataAccess.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManagerHotelApp.AllUser
{
    public partial class UC_AddRoom : UserControl
    {
        public UC_AddRoom()
        {
            InitializeComponent();

        }

        private void UC_AddRoom_Load(object sender, EventArgs e)
        {
            RoomDAO dao = new RoomDAO();
            List<Room> rooms = dao.GetAllRooms();
            dgvRoomList.DataSource = rooms;
            if (dgvRoomList.Columns.Contains("Bookings"))
            {
                dgvRoomList.Columns["Bookings"].Visible = false;
            }
        }

        private void btnAddRoom_Click(object sender, EventArgs e)
        {
            if (txtRoomNumber.Text != "" && cboRoomType.Text != "" && txtPrice.Text != "")
            {
                string roomNumber = txtRoomNumber.Text;
                string type = cboRoomType.Text;
                decimal price = decimal.Parse(txtPrice.Text);
                if (IsRoomNumberDuplicate(roomNumber))
                {
                    MessageBox.Show("Room number already exists. Please use a different room number.", "Duplicate Room Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    RoomDAO dao = new RoomDAO();
                    Room rooms = new Room()
                    {
                        RoomName = roomNumber,
                        RoomType = type,
                        Price = price,
                        Status = "NO"
                    };
                    dao.AddNewRoom(rooms);
                    MessageBox.Show("Add a new rooms successfully!", "Successful");
                    UC_AddRoom_Load(this, null);
                    ClearAll();
                }
            }
        }

        private void ClearAll()
        {
            txtRoomNumber.Clear();
            cboRoomType.SelectedIndex = -1;
            txtPrice.Clear();
        }

        private bool IsRoomNumberDuplicate(string roomNumber)
        {
            RoomDAO dao = new RoomDAO();
            return dao.IsRoomNumberExists(roomNumber);
        }

        private void UC_AddRoom_Enter(object sender, EventArgs e)
        {
            UC_AddRoom_Load(this, null);
        }

        private void UC_AddRoom_Leave(object sender, EventArgs e)
        {
            ClearAll();
        }
    }
}
