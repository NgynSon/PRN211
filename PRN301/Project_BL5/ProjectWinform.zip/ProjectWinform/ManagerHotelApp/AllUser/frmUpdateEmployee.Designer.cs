﻿namespace ManagerHotelApp.AllUser
{
    partial class frmUpdateEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            btnSave = new Guna.UI2.WinForms.Guna2Button();
            cboPosition = new Guna.UI2.WinForms.Guna2ComboBox();
            label11 = new Label();
            txtSalary = new Guna.UI2.WinForms.Guna2TextBox();
            label9 = new Label();
            txtPassword = new Guna.UI2.WinForms.Guna2TextBox();
            label8 = new Label();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            label10 = new Label();
            txtAddress = new Guna.UI2.WinForms.Guna2TextBox();
            label7 = new Label();
            txtPhone = new Guna.UI2.WinForms.Guna2TextBox();
            label6 = new Label();
            txtLastName = new Guna.UI2.WinForms.Guna2TextBox();
            label4 = new Label();
            txtFirstName = new Guna.UI2.WinForms.Guna2TextBox();
            label5 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnSave
            // 
            btnSave.BorderRadius = 12;
            btnSave.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            btnSave.BorderThickness = 1;
            btnSave.CheckedState.FillColor = Color.FromArgb(0, 118, 221);
            btnSave.CheckedState.ForeColor = Color.White;
            btnSave.CustomizableEdges = customizableEdges1;
            btnSave.DisabledState.BorderColor = Color.DarkGray;
            btnSave.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSave.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSave.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSave.FillColor = Color.White;
            btnSave.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnSave.ForeColor = Color.Black;
            btnSave.Location = new Point(483, 409);
            btnSave.Name = "btnSave";
            btnSave.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnSave.Size = new Size(110, 53);
            btnSave.TabIndex = 137;
            btnSave.Text = "Save";
            btnSave.Click += btnSave_Click;
            // 
            // cboPosition
            // 
            cboPosition.BackColor = Color.Transparent;
            cboPosition.CustomizableEdges = customizableEdges3;
            cboPosition.DrawMode = DrawMode.OwnerDrawFixed;
            cboPosition.DropDownStyle = ComboBoxStyle.DropDownList;
            cboPosition.FocusedColor = Color.FromArgb(94, 148, 255);
            cboPosition.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cboPosition.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cboPosition.ForeColor = Color.Black;
            cboPosition.ItemHeight = 30;
            cboPosition.Items.AddRange(new object[] { "Receptionist", "Guard", "Housekeeper", "Chef" });
            cboPosition.Location = new Point(50, 343);
            cboPosition.Name = "cboPosition";
            cboPosition.ShadowDecoration.CustomizableEdges = customizableEdges4;
            cboPosition.Size = new Size(242, 36);
            cboPosition.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            cboPosition.TabIndex = 136;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label11.Location = new Point(50, 318);
            label11.Name = "label11";
            label11.Size = new Size(51, 17);
            label11.TabIndex = 135;
            label11.Text = "Position";
            // 
            // txtSalary
            // 
            txtSalary.CustomizableEdges = customizableEdges5;
            txtSalary.DefaultText = "";
            txtSalary.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSalary.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSalary.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSalary.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSalary.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSalary.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtSalary.ForeColor = Color.Black;
            txtSalary.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSalary.Location = new Point(351, 347);
            txtSalary.Name = "txtSalary";
            txtSalary.PasswordChar = '\0';
            txtSalary.PlaceholderText = "Enter salary";
            txtSalary.SelectedText = "";
            txtSalary.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtSalary.Size = new Size(242, 32);
            txtSalary.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtSalary.TabIndex = 134;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label9.Location = new Point(351, 318);
            label9.Name = "label9";
            label9.Size = new Size(42, 17);
            label9.TabIndex = 133;
            label9.Text = "Salary";
            // 
            // txtPassword
            // 
            txtPassword.CustomizableEdges = customizableEdges7;
            txtPassword.DefaultText = "";
            txtPassword.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPassword.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPassword.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPassword.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPassword.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPassword.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtPassword.ForeColor = Color.Black;
            txtPassword.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPassword.Location = new Point(351, 263);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '\0';
            txtPassword.PlaceholderText = "Enter password";
            txtPassword.SelectedText = "";
            txtPassword.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtPassword.Size = new Size(242, 32);
            txtPassword.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtPassword.TabIndex = 132;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label8.Location = new Point(351, 234);
            label8.Name = "label8";
            label8.Size = new Size(60, 17);
            label8.TabIndex = 131;
            label8.Text = "Password";
            // 
            // txtEmail
            // 
            txtEmail.CustomizableEdges = customizableEdges9;
            txtEmail.DefaultText = "";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtEmail.ForeColor = Color.Black;
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(351, 187);
            txtEmail.Name = "txtEmail";
            txtEmail.PasswordChar = '\0';
            txtEmail.PlaceholderText = "Enter email";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtEmail.Size = new Size(242, 32);
            txtEmail.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtEmail.TabIndex = 130;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label10.Location = new Point(351, 158);
            label10.Name = "label10";
            label10.Size = new Size(38, 17);
            label10.TabIndex = 129;
            label10.Text = "Email";
            // 
            // txtAddress
            // 
            txtAddress.CustomizableEdges = customizableEdges11;
            txtAddress.DefaultText = "";
            txtAddress.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtAddress.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtAddress.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtAddress.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtAddress.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddress.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtAddress.ForeColor = Color.Black;
            txtAddress.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddress.Location = new Point(351, 104);
            txtAddress.Name = "txtAddress";
            txtAddress.PasswordChar = '\0';
            txtAddress.PlaceholderText = "Enter address";
            txtAddress.SelectedText = "";
            txtAddress.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtAddress.Size = new Size(242, 32);
            txtAddress.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtAddress.TabIndex = 128;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label7.Location = new Point(351, 75);
            label7.Name = "label7";
            label7.Size = new Size(51, 17);
            label7.TabIndex = 127;
            label7.Text = "Address";
            // 
            // txtPhone
            // 
            txtPhone.CustomizableEdges = customizableEdges13;
            txtPhone.DefaultText = "";
            txtPhone.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPhone.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPhone.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPhone.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPhone.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhone.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtPhone.ForeColor = Color.Black;
            txtPhone.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhone.Location = new Point(50, 263);
            txtPhone.Name = "txtPhone";
            txtPhone.PasswordChar = '\0';
            txtPhone.PlaceholderText = "Enter phone number";
            txtPhone.SelectedText = "";
            txtPhone.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtPhone.Size = new Size(242, 32);
            txtPhone.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtPhone.TabIndex = 126;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label6.Location = new Point(50, 234);
            label6.Name = "label6";
            label6.Size = new Size(89, 17);
            label6.TabIndex = 125;
            label6.Text = "Phone number";
            // 
            // txtLastName
            // 
            txtLastName.CustomizableEdges = customizableEdges15;
            txtLastName.DefaultText = "";
            txtLastName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtLastName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtLastName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtLastName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtLastName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtLastName.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtLastName.ForeColor = Color.Black;
            txtLastName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtLastName.Location = new Point(50, 182);
            txtLastName.Name = "txtLastName";
            txtLastName.PasswordChar = '\0';
            txtLastName.PlaceholderText = "Enter last name";
            txtLastName.SelectedText = "";
            txtLastName.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtLastName.Size = new Size(242, 32);
            txtLastName.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtLastName.TabIndex = 124;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label4.Location = new Point(50, 150);
            label4.Name = "label4";
            label4.Size = new Size(68, 17);
            label4.TabIndex = 123;
            label4.Text = "Last Name";
            // 
            // txtFirstName
            // 
            txtFirstName.CustomizableEdges = customizableEdges17;
            txtFirstName.DefaultText = "";
            txtFirstName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtFirstName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtFirstName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtFirstName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtFirstName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFirstName.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtFirstName.ForeColor = Color.Black;
            txtFirstName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFirstName.Location = new Point(50, 104);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.PasswordChar = '\0';
            txtFirstName.PlaceholderText = "Enter first name";
            txtFirstName.SelectedText = "";
            txtFirstName.ShadowDecoration.CustomizableEdges = customizableEdges18;
            txtFirstName.Size = new Size(242, 32);
            txtFirstName.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtFirstName.TabIndex = 122;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label5.Location = new Point(50, 75);
            label5.Name = "label5";
            label5.Size = new Size(69, 17);
            label5.TabIndex = 121;
            label5.Text = "First Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(220, 28);
            label1.TabIndex = 138;
            label1.Text = "Update Employee";
            // 
            // frmUpdateEmployee
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(642, 490);
            Controls.Add(label1);
            Controls.Add(btnSave);
            Controls.Add(cboPosition);
            Controls.Add(label11);
            Controls.Add(txtSalary);
            Controls.Add(label9);
            Controls.Add(txtPassword);
            Controls.Add(label8);
            Controls.Add(txtEmail);
            Controls.Add(label10);
            Controls.Add(txtAddress);
            Controls.Add(label7);
            Controls.Add(txtPhone);
            Controls.Add(label6);
            Controls.Add(txtLastName);
            Controls.Add(label4);
            Controls.Add(txtFirstName);
            Controls.Add(label5);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmUpdateEmployee";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "frmUpdateEmployee";
            Load += frmUpdateEmployee_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button btnSave;
        private Guna.UI2.WinForms.Guna2ComboBox cboPosition;
        private Label label11;
        private Guna.UI2.WinForms.Guna2TextBox txtSalary;
        private Label label9;
        private Guna.UI2.WinForms.Guna2TextBox txtPassword;
        private Label label8;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Label label10;
        private Guna.UI2.WinForms.Guna2TextBox txtAddress;
        private Label label7;
        private Guna.UI2.WinForms.Guna2TextBox txtPhone;
        private Label label6;
        private Guna.UI2.WinForms.Guna2TextBox txtLastName;
        private Label label4;
        private Guna.UI2.WinForms.Guna2TextBox txtFirstName;
        private Label label5;
        private Label label1;
    }
}