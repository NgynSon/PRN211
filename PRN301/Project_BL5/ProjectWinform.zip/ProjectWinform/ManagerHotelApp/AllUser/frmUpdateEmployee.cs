﻿using DataAccess.DAOs;
using DataAccess.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManagerHotelApp.AllUser
{
    public partial class frmUpdateEmployee : Form
    {
        private int employeeId;
        private EmployeeDAO employeeDAO;
        public frmUpdateEmployee(int employeeId)
        {
            InitializeComponent();
            this.employeeId = employeeId;
            this.employeeDAO = new EmployeeDAO();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string firstName = txtFirstName.Text;
            string lastName = txtLastName.Text;
            string address = txtAddress.Text;
            string email = txtEmail.Text;
            string phone = txtPhone.Text;
            decimal salary;
            if (!decimal.TryParse(txtSalary.Text, out salary))
            {
                MessageBox.Show("Invalid salary value!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string position = cboPosition.Text;

            Employee updatedEmployee = new Employee
            {
                EmployeeId = employeeId,
                FirstName = firstName,
                LastName = lastName,
                Address = address,
                Email = email,
                Phone = phone,
                Salary = salary,
                Position = position
            };

            try
            {
                employeeDAO.UpdateEmployee(updatedEmployee);
                MessageBox.Show("Employee updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating employee: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void frmUpdateEmployee_Load(object sender, EventArgs e)
        {
            
            Employee employee = employeeDAO.GetEmployeeById(employeeId);
            if (employee != null)
            {
                txtFirstName.Text = employee.FirstName;
                txtLastName.Text = employee.LastName;
                txtAddress.Text = employee.Address;
                txtEmail.Text = employee.Email;
                txtPhone.Text = employee.Phone;
                txtSalary.Text = employee.Salary.ToString();
                cboPosition.Text = employee.Position;
            }
            else
            {
                MessageBox.Show("Employee not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close(); 
            }
        }
    }
}
