﻿using DataAccess.DAOs;
using DataAccess.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManagerHotelApp.AllUser
{
    public partial class UC_Employees : UserControl
    {
        public UC_Employees()
        {
            InitializeComponent();
        }

        private void UC_Employees_Load(object sender, EventArgs e)
        {
            loadEmployee();
        }
        private void loadEmployee()
        {
            EmployeeDAO employeeDAO = new EmployeeDAO();
            List<Employee> employee = employeeDAO.GetAllEmployees();

            dgvListDetails.DataSource = employee;
            dgvListEmployee.DataSource = employee;
        }
        public void ClearAll()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtEmail.Clear();
            txtPhone.Clear();
            txtSalary.Clear();
            txtAddress.Clear();
            txtPassword.Clear();
            cboPosition.SelectedIndex = -1;
        }

        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            if (txtFirstName.Text != "" && txtLastName.Text != "" && txtAddress.Text != "" || txtEmail.Text != "" &&
                txtPassword.Text != "" && txtSalary.Text != "" && txtPhone.Text != "" && cboPosition.Text != "")
            {
                string firstName = txtFirstName.Text;
                string lastName = txtLastName.Text;
                string address = txtAddress.Text;
                string email = txtEmail.Text;
                string password = txtPassword.Text;
                decimal salary = decimal.Parse(txtSalary.Text);
                string phone = txtPhone.Text;
                string position = cboPosition.Text;

                Employee newEmployee = new Employee()
                {
                    FirstName = firstName,
                    LastName = lastName,
                    Address = address,
                    Email = email,
                    Password = password,
                    Salary = salary,
                    Phone = phone,
                    Position = position
                };

                EmployeeDAO employeeDAO = new EmployeeDAO();
                employeeDAO.AddNewEmployee(newEmployee);
                MessageBox.Show("Add a new employee successfully!", "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearAll();
                loadEmployee();
            }
            else
            {
                MessageBox.Show("Please fill in the blanks", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dgvListEmployee_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Get the DataGridViewRow corresponding to the clicked cell
                DataGridViewRow selectedRow = dgvListEmployee.Rows[e.RowIndex];

                // Extract data from the selected row's cells
                string firstName = selectedRow.Cells["FirstName"].Value.ToString();
                string lastName = selectedRow.Cells["LastName"].Value.ToString();
                string address = selectedRow.Cells["Address"].Value.ToString();
                string email = selectedRow.Cells["Email"].Value.ToString();
                string phone = selectedRow.Cells["Phone"].Value.ToString();
                string position = selectedRow.Cells["Position"].Value.ToString();
                decimal salary = Convert.ToDecimal(selectedRow.Cells["Salary"].Value);

                // Update other UI elements with the selected employee's information
                txtName.Text = firstName + lastName;
                txtAddress1.Text = address;
                txtPhoneNumber.Text = phone;
                txtPosition.Text = position;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvListEmployee.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgvListEmployee.SelectedRows[0];
                int employeeId = Convert.ToInt32(selectedRow.Cells["EmployeeId"].Value);

                DialogResult result = MessageBox.Show("Are you sure you want to delete this employee?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    EmployeeDAO employeeDAO = new EmployeeDAO();
                    employeeDAO.DeleteEmployee(employeeId);

                    MessageBox.Show("Employee deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    loadEmployee();
                }
            }
            else
            {
                MessageBox.Show("Please select an employee to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvListEmployee.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgvListEmployee.SelectedRows[0];
                int employeeId = Convert.ToInt32(selectedRow.Cells["EmployeeId"].Value);

                frmUpdateEmployee updateForm = new frmUpdateEmployee(employeeId);
                updateForm.ShowDialog();


                loadEmployee();
            }
            else
            {
                MessageBox.Show("Please select an employee to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void reportEmp_Click(object sender, EventArgs e)
        {
            frmReportEmp reportEmp = new frmReportEmp();
            reportEmp.ShowDialog();
        }
    }
}
