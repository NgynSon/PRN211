﻿namespace ManagerHotelApp.AllUser
{
    partial class UC_AddRoom
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            cboRoomType = new Guna.UI2.WinForms.Guna2ComboBox();
            label3 = new Label();
            btnAddRoom = new Guna.UI2.WinForms.Guna2Button();
            txtPrice = new Guna.UI2.WinForms.Guna2TextBox();
            label5 = new Label();
            txtRoomNumber = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            label1 = new Label();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            dgvRoomList = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvRoomList).BeginInit();
            SuspendLayout();
            // 
            // cboRoomType
            // 
            cboRoomType.BackColor = Color.Transparent;
            cboRoomType.CustomizableEdges = customizableEdges1;
            cboRoomType.DrawMode = DrawMode.OwnerDrawFixed;
            cboRoomType.DropDownStyle = ComboBoxStyle.DropDownList;
            cboRoomType.FocusedColor = Color.FromArgb(94, 148, 255);
            cboRoomType.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cboRoomType.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cboRoomType.ForeColor = Color.Black;
            cboRoomType.ItemHeight = 25;
            cboRoomType.Items.AddRange(new object[] { "Single", "Double", "Couple", "Family", "Vip" });
            cboRoomType.Location = new Point(615, 203);
            cboRoomType.Name = "cboRoomType";
            cboRoomType.ShadowDecoration.CustomizableEdges = customizableEdges2;
            cboRoomType.Size = new Size(229, 31);
            cboRoomType.TabIndex = 23;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(615, 170);
            label3.Name = "label3";
            label3.Size = new Size(88, 20);
            label3.TabIndex = 22;
            label3.Text = "Room type";
            // 
            // btnAddRoom
            // 
            btnAddRoom.BorderRadius = 18;
            btnAddRoom.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            btnAddRoom.BorderThickness = 1;
            btnAddRoom.CheckedState.FillColor = Color.FromArgb(0, 118, 221);
            btnAddRoom.CheckedState.ForeColor = Color.White;
            btnAddRoom.CustomizableEdges = customizableEdges3;
            btnAddRoom.DisabledState.BorderColor = Color.DarkGray;
            btnAddRoom.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAddRoom.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAddRoom.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAddRoom.FillColor = Color.White;
            btnAddRoom.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnAddRoom.ForeColor = Color.Black;
            btnAddRoom.Location = new Point(615, 361);
            btnAddRoom.Name = "btnAddRoom";
            btnAddRoom.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnAddRoom.Size = new Size(229, 45);
            btnAddRoom.TabIndex = 21;
            btnAddRoom.Text = "Add Room";
            btnAddRoom.Click += btnAddRoom_Click;
            // 
            // txtPrice
            // 
            txtPrice.CustomizableEdges = customizableEdges5;
            txtPrice.DefaultText = "";
            txtPrice.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPrice.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPrice.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPrice.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPrice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPrice.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            txtPrice.ForeColor = Color.Black;
            txtPrice.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPrice.Location = new Point(615, 279);
            txtPrice.Margin = new Padding(3, 4, 3, 4);
            txtPrice.Name = "txtPrice";
            txtPrice.PasswordChar = '\0';
            txtPrice.PlaceholderText = "";
            txtPrice.SelectedText = "";
            txtPrice.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtPrice.Size = new Size(229, 48);
            txtPrice.TabIndex = 20;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(615, 255);
            label5.Name = "label5";
            label5.Size = new Size(46, 20);
            label5.TabIndex = 19;
            label5.Text = "Price";
            // 
            // txtRoomNumber
            // 
            txtRoomNumber.CustomizableEdges = customizableEdges7;
            txtRoomNumber.DefaultText = "";
            txtRoomNumber.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtRoomNumber.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtRoomNumber.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtRoomNumber.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtRoomNumber.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRoomNumber.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            txtRoomNumber.ForeColor = Color.Black;
            txtRoomNumber.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRoomNumber.Location = new Point(615, 109);
            txtRoomNumber.Margin = new Padding(3, 4, 3, 4);
            txtRoomNumber.Name = "txtRoomNumber";
            txtRoomNumber.PasswordChar = '\0';
            txtRoomNumber.PlaceholderText = "";
            txtRoomNumber.SelectedText = "";
            txtRoomNumber.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtRoomNumber.Size = new Size(229, 48);
            txtRoomNumber.TabIndex = 16;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(615, 71);
            label2.Name = "label2";
            label2.Size = new Size(111, 20);
            label2.TabIndex = 15;
            label2.Text = "Room number";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(29, 14);
            label1.Name = "label1";
            label1.Size = new Size(136, 28);
            label1.TabIndex = 14;
            label1.Text = "Add Room";
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.BorderRadius = 30;
            guna2Elipse1.TargetControl = this;
            // 
            // dgvRoomList
            // 
            dgvRoomList.BackgroundColor = SystemColors.ButtonFace;
            dgvRoomList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvRoomList.Location = new Point(29, 71);
            dgvRoomList.Name = "dgvRoomList";
            dgvRoomList.RowTemplate.Height = 25;
            dgvRoomList.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvRoomList.Size = new Size(524, 334);
            dgvRoomList.TabIndex = 24;
            // 
            // UC_AddRoom
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(dgvRoomList);
            Controls.Add(cboRoomType);
            Controls.Add(label3);
            Controls.Add(btnAddRoom);
            Controls.Add(txtPrice);
            Controls.Add(label5);
            Controls.Add(txtRoomNumber);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "UC_AddRoom";
            Size = new Size(895, 477);
            Load += UC_AddRoom_Load;
            Enter += UC_AddRoom_Enter;
            Leave += UC_AddRoom_Leave;
            ((System.ComponentModel.ISupportInitialize)dgvRoomList).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Guna.UI2.WinForms.Guna2ComboBox cboRoomType;
        private Label label3;
        private Guna.UI2.WinForms.Guna2Button btnAddRoom;
        private Guna.UI2.WinForms.Guna2TextBox txtPrice;
        private Label label5;
        private Guna.UI2.WinForms.Guna2TextBox txtRoomNumber;
        private Label label2;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private DataGridView dgvRoomList;
    }
}
