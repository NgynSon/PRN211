﻿using ManagerHotelApp.AllUser;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManagerHotelApp
{
    public partial class frmDashBoard : Form
    {
        public frmDashBoard()
        {
            InitializeComponent();

        }
        private void frmDashBoard_Load(object sender, EventArgs e)
        {

            uC_AddRoom1.Visible = false;
            uC_Register1.Visible = false;
            uC_Checkout1.Visible = false;
            uC_CustomerDetail1.Visible = false;
            uC_Employees1.Visible = false;
            btnAddRoom.PerformClick();

        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAddRoom_Click(object sender, EventArgs e)
        {
            panelMoving.Left = btnAddRoom.Left + 50;
            uC_AddRoom1.Visible = true;
            uC_AddRoom1.BringToFront();
        }

        private void btnCusRegister_Click(object sender, EventArgs e)
        {
            panelMoving.Left = btnCusRegister.Left + 60;
            uC_Register1.Visible = true;
            uC_Register1.BringToFront();
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            panelMoving.Left = btnCheckout.Left + 60;
            uC_Checkout1.Visible = true;
            uC_Checkout1.BringToFront();
        }

        private void btnCustomerDetails_Click(object sender, EventArgs e)
        {
            panelMoving.Left = btnCustomerDetails.Left + 60;
            uC_CustomerDetail1.Visible = true;
            uC_CustomerDetail1.BringToFront();
        }

        private void btnMangeEmployee_Click(object sender, EventArgs e)
        {
            panelMoving.Left = btnMangeEmployee.Left + 60;
            uC_Employees1.Visible = true;
            uC_Employees1.BringToFront();
        }
    }
}
