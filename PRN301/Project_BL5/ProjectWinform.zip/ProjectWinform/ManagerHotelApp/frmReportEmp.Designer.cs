﻿namespace ManagerHotelApp
{
    partial class frmReportEmp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvListDetails = new DataGridView();
            label3 = new Label();
            txtSearch = new TextBox();
            label1 = new Label();
            label2 = new Label();
            cmbPos = new ComboBox();
            btnExport = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvListDetails).BeginInit();
            SuspendLayout();
            // 
            // dgvListDetails
            // 
            dgvListDetails.BackgroundColor = SystemColors.AppWorkspace;
            dgvListDetails.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvListDetails.Location = new Point(12, 132);
            dgvListDetails.Name = "dgvListDetails";
            dgvListDetails.RowTemplate.Height = 25;
            dgvListDetails.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvListDetails.Size = new Size(818, 259);
            dgvListDetails.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(12, 35);
            label3.Name = "label3";
            label3.Size = new Size(170, 23);
            label3.TabIndex = 4;
            label3.Text = "Employee Details";
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(451, 35);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(379, 23);
            txtSearch.TabIndex = 5;
            txtSearch.TextChanged += txtSearch_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(371, 35);
            label1.Name = "label1";
            label1.Size = new Size(74, 23);
            label1.TabIndex = 6;
            label1.Text = "Search";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(365, 87);
            label2.Name = "label2";
            label2.Size = new Size(80, 23);
            label2.TabIndex = 8;
            label2.Text = "Position";
            // 
            // cmbPos
            // 
            cmbPos.FormattingEnabled = true;
            cmbPos.Location = new Point(451, 87);
            cmbPos.Name = "cmbPos";
            cmbPos.Size = new Size(163, 23);
            cmbPos.TabIndex = 9;
            cmbPos.SelectedIndexChanged += cmbPos_SelectedIndexChanged;
            // 
            // btnExport
            // 
            btnExport.Location = new Point(695, 430);
            btnExport.Name = "btnExport";
            btnExport.Size = new Size(135, 44);
            btnExport.TabIndex = 10;
            btnExport.Text = "Export";
            btnExport.UseVisualStyleBackColor = true;
            btnExport.Click += btnExport_Click;
            // 
            // frmReportEmp
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(842, 502);
            Controls.Add(btnExport);
            Controls.Add(cmbPos);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtSearch);
            Controls.Add(label3);
            Controls.Add(dgvListDetails);
            Name = "frmReportEmp";
            Text = "frmReportEmp";
            Load += frmReportEmp_Load;
            ((System.ComponentModel.ISupportInitialize)dgvListDetails).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvListDetails;
        private Label label3;
        private TextBox txtSearch;
        private Label label1;
        private Label label2;
        private ComboBox cmbPos;
        private Button btnExport;
    }
}